/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;

import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledEditorKit;
import javax.swing.text.StyledEditorKit.StyledTextAction;
import javax.swing.text.AttributeSet;

/**
 *
 * @author robertsonbrinker
 */
public class StrikethroughAction extends StyledTextAction {

    /**
     * Constructs a new UnderlineAction.
     */
    public StrikethroughAction() {
        super("font-strikethrough");
    }

    /**
     * Toggles the StrikeThrough attribute.
     *
     * @param e the action event
     */
    public void actionPerformed(ActionEvent e) {
        JEditorPane editor = getEditor(e);
        if (editor != null) {
            StyledEditorKit kit = getStyledEditorKit(editor);
            MutableAttributeSet attr = kit.getInputAttributes();
            boolean strikethrough = (StyleConstants.isStrikeThrough(attr)) ? false : true;
            SimpleAttributeSet sas = new SimpleAttributeSet();
            StyleConstants.setStrikeThrough(sas, strikethrough);
            setCharacterAttributes(editor, sas, false);
        }
    }
}
