/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.text.AttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.text.StyledEditorKit;
import javax.swing.KeyStroke;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.Document;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import java.awt.Event;
import java.awt.font.TextAttribute;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.JFileChooser;
import javax.swing.text.BadLocationException;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.JOptionPane;
import java.util.StringTokenizer;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;
import javax.swing.text.Style;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.UIManager;
import javax.swing.text.Element;

/**
 *
 * @author Xi Song
 */
public class ScribPadGui extends javax.swing.JFrame {

    //Undo and redo
    private Document editDocument;
    protected UndoHandler undoHandler = new UndoHandler();
    protected UndoManager undoManager = new UndoManager();
    private UndoAction undoAction = null;
    private RedoAction redoAction = null;
    private Color highlightColor=Color.YELLOW;
    
    /**
     * Creates new form ScribPadGui
     */
    String fileName;
    Color clrCrnt;
    Color clrhighlit;
    public ScribPadGui() {
        initComponents();
       
        // Start of font styling (Sarmad)
        Dimension layout = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(layout.width/2 - this.getWidth()/2, layout.height/2 - this.getHeight()/2);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        GraphicsEnvironment gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontNames = gEnv.getAvailableFontFamilyNames();
        ComboBoxModel model = new DefaultComboBoxModel(fontNames);
        fontDesign.setModel(model);
        // End of font styling (Sarmad)
        // Start of Bolding, Italicising, Underlining, Strikethrough (Robertson)
        fontBoldMenuItem.addActionListener(new StyledEditorKit.BoldAction());
        fontItalicMenuItem.addActionListener(new StyledEditorKit.ItalicAction());
        fontUnderlineMenuItem.addActionListener(new StyledEditorKit.UnderlineAction());
        fontStrikethroughMenuItem.addActionListener(new StrikethroughAction());
        boldQuickButton.addActionListener(new StyledEditorKit.BoldAction());
        italicQuickButton.addActionListener(new StyledEditorKit.ItalicAction());
        underlineQuickButton.addActionListener(new StyledEditorKit.UnderlineAction());
        strikethroughQuickButton.addActionListener(new StrikethroughAction());
        // End of Bolding, Italicising, Underlining, Strikethrough (Robertson)
        // Start of Uppercase/Lowercase (Robertson)
        lowercaseMenuItem.addActionListener(new LowercaseAction());
        uppercaseMenuItem.addActionListener(new UppercaseAction());
        // End of Uppercase/Lowercase (Robertson)
        // Undo/Redo (Logan)
        editDocument = jTextPane1.getDocument();
        editDocument.addUndoableEditListener(undoHandler);
        
        KeyStroke undoKeystroke = KeyStroke.getKeyStroke(KeyEvent.VK_Z, Event.CTRL_MASK);
        KeyStroke redoKeystroke = KeyStroke.getKeyStroke(KeyEvent.VK_Y, Event.CTRL_MASK);

        undoAction = new UndoAction();
        jTextPane1.getInputMap().put(undoKeystroke, "undoKeystroke");
        jTextPane1.getActionMap().put("undoKeystroke", undoAction);

        redoAction = new RedoAction();
        jTextPane1.getInputMap().put(redoKeystroke, "redoKeystroke");
        jTextPane1.getActionMap().put("redoKeystroke", redoAction);
        // End of Undo/Redo (Logan)
    }
    
    //Begin of "Search function" edited by Xi
    class MyHighlightPainter extends DefaultHighlighter.DefaultHighlightPainter{
          public MyHighlightPainter(Color color){
              super(color);
          }
           
      }
    
        
         Highlighter.HighlightPainter myHighlightPainter = new MyHighlightPainter(Color.cyan);
         
         
         public void removeHighlights(JTextComponent textComp){
             Highlighter hilite = textComp.getHighlighter();
             Highlighter.Highlight[] hilites = hilite.getHighlights();
             
             for(int i=0; i<hilites.length;i++){
                 if(hilites[i].getPainter() instanceof MyHighlightPainter){
                     hilite.removeHighlight(hilites[i]);
                 }
             }
         }
         
         public void highlight(JTextComponent textComp, String pattern){
             
             removeHighlights(textComp);
             
             try{
                 
                 Highlighter hilite = textComp.getHighlighter();
                 Document doc =textComp.getDocument();
                 String text = doc.getText(0, doc.getLength());
                 int pos=0;
                 
                 while((pos=text.toUpperCase().indexOf(pattern.toUpperCase(),pos))>=0){
                     hilite.addHighlight(pos, pos+pattern.length(), myHighlightPainter);
                     pos += pattern.length();
                 }
             }
             catch(Exception e){
                 
             }
             
         }
         //End of "Search Function" edited by Xi

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        quickToolBar = new javax.swing.JToolBar();
        newFileQuickButton = new javax.swing.JButton();
        openFileQuickButton = new javax.swing.JButton();
        saveFileQuickButton = new javax.swing.JButton();
        undoQuickButton = new javax.swing.JButton();
        redoQuickButton = new javax.swing.JButton();
        copyTextQuickButton = new javax.swing.JButton();
        cutTextQuickButton = new javax.swing.JButton();
        pasteTextQuickButton = new javax.swing.JButton();
        highlightQuickButton = new javax.swing.JButton();
        clearHighlightQuickButton = new javax.swing.JButton();
        boldQuickButton = new javax.swing.JButton();
        italicQuickButton = new javax.swing.JButton();
        underlineQuickButton = new javax.swing.JButton();
        strikethroughQuickButton = new javax.swing.JButton();
        clearFormattingQuick = new javax.swing.JButton();
        changeColorQuickBtn = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        jLabel1 = new javax.swing.JLabel();
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        fontDesign = new javax.swing.JComboBox<String>();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        filler3 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        jLabel2 = new javax.swing.JLabel();
        filler4 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        fontSize = new javax.swing.JComboBox<String>();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        filler5 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        searchButtonItem = new javax.swing.JButton();
        filler6 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        clearSearch = new javax.swing.JButton();
        filler7 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        searchTextfield = new javax.swing.JTextField();
        filler9 = new javax.swing.Box.Filler(new java.awt.Dimension(30, 1), new java.awt.Dimension(30, 1), new java.awt.Dimension(30, 1));
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        newFile = new javax.swing.JMenuItem();
        openFile = new javax.swing.JMenuItem();
        saveFile = new javax.swing.JMenuItem();
        saveAsFile = new javax.swing.JMenuItem();
        PrintFile = new javax.swing.JMenuItem();
        exitFile = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        undoMenuItem = new javax.swing.JMenuItem();
        redoMenuItem = new javax.swing.JMenuItem();
        cutText = new javax.swing.JMenuItem();
        copyText = new javax.swing.JMenuItem();
        pasteText = new javax.swing.JMenuItem();
        selectAllMenuItem = new javax.swing.JMenuItem();
        insertMenu = new javax.swing.JMenu();
        insertImageMenuItem = new javax.swing.JMenuItem();
        formatMenu = new javax.swing.JMenu();
        fontEditMenu = new javax.swing.JMenu();
        fontBoldMenuItem = new javax.swing.JMenuItem();
        fontItalicMenuItem = new javax.swing.JMenuItem();
        fontUnderlineMenuItem = new javax.swing.JMenuItem();
        fontStrikethroughMenuItem = new javax.swing.JMenuItem();
        capitalizationMenu = new javax.swing.JMenu();
        lowercaseMenuItem = new javax.swing.JMenuItem();
        uppercaseMenuItem = new javax.swing.JMenuItem();
        fontColorMenu = new javax.swing.JMenu();
        fontHighlightColorMenuItem = new javax.swing.JMenuItem();
        clearFormatting = new javax.swing.JMenuItem();
        toolMenu = new javax.swing.JMenu();
        wordCounterMenuItem = new javax.swing.JMenuItem();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        quickToolBar.setRollover(true);
        quickToolBar.setAlignmentY(0.5F);

        newFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/newFile1.png"))); // NOI18N
        newFileQuickButton.setToolTipText("New");
        newFileQuickButton.setFocusable(false);
        newFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        newFileQuickButton.setMaximumSize(new java.awt.Dimension(30, 40));
        newFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        newFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(newFileQuickButton);

        openFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/document_open.png"))); // NOI18N
        openFileQuickButton.setToolTipText("Open");
        openFileQuickButton.setFocusable(false);
        openFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        openFileQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        openFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        openFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(openFileQuickButton);

        saveFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/save_file.png"))); // NOI18N
        saveFileQuickButton.setToolTipText("Save");
        saveFileQuickButton.setFocusable(false);
        saveFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveFileQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        saveFileQuickButton.setMinimumSize(new java.awt.Dimension(39, 39));
        saveFileQuickButton.setPreferredSize(new java.awt.Dimension(35, 35));
        saveFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        saveFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(saveFileQuickButton);

        undoQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Undo.png"))); // NOI18N
        undoQuickButton.setToolTipText("Undo");
        undoQuickButton.setFocusable(false);
        undoQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        undoQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        undoQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(undoQuickButton);

        redoQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Redo.png"))); // NOI18N
        redoQuickButton.setFocusable(false);
        redoQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        redoQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        redoQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(redoQuickButton);

        copyTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/copy.png"))); // NOI18N
        copyTextQuickButton.setToolTipText("Copy");
        copyTextQuickButton.setFocusable(false);
        copyTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        copyTextQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        copyTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        copyTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(copyTextQuickButton);

        cutTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/clipboard_cut.png"))); // NOI18N
        cutTextQuickButton.setToolTipText("Cut");
        cutTextQuickButton.setFocusable(false);
        cutTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cutTextQuickButton.setMaximumSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setMinimumSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setPreferredSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cutTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(cutTextQuickButton);

        pasteTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/paste.png"))); // NOI18N
        pasteTextQuickButton.setToolTipText("Paste");
        pasteTextQuickButton.setFocusable(false);
        pasteTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        pasteTextQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        pasteTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        pasteTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(pasteTextQuickButton);

        highlightQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/highlight_black.png"))); // NOI18N
        highlightQuickButton.setToolTipText("Highlight");
        highlightQuickButton.setFocusable(false);
        highlightQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        highlightQuickButton.setMaximumSize(new java.awt.Dimension(39, 39));
        highlightQuickButton.setMinimumSize(new java.awt.Dimension(39, 39));
        highlightQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        highlightQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                highlightQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(highlightQuickButton);

        clearHighlightQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Eraser-icon_cr.jpg"))); // NOI18N
        clearHighlightQuickButton.setFocusable(false);
        clearHighlightQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearHighlightQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearHighlightQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearHighlightQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(clearHighlightQuickButton);

        boldQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/bold.png"))); // NOI18N
        boldQuickButton.setToolTipText("Bold Text");
        boldQuickButton.setFocusable(false);
        boldQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        boldQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(boldQuickButton);

        italicQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/italic.png"))); // NOI18N
        italicQuickButton.setToolTipText("Italicize Text");
        italicQuickButton.setFocusable(false);
        italicQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        italicQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(italicQuickButton);

        underlineQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/underline.png"))); // NOI18N
        underlineQuickButton.setToolTipText("Underline Text");
        underlineQuickButton.setFocusable(false);
        underlineQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        underlineQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(underlineQuickButton);

        strikethroughQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/strikethrough.png"))); // NOI18N
        strikethroughQuickButton.setToolTipText("Strikethrough Text");
        strikethroughQuickButton.setFocusable(false);
        strikethroughQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        strikethroughQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(strikethroughQuickButton);

        clearFormattingQuick.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/eraser.png"))); // NOI18N
        clearFormattingQuick.setToolTipText("Clear Formatting");
        clearFormattingQuick.setFocusable(false);
        clearFormattingQuick.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearFormattingQuick.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearFormattingQuick.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearFormattingQuickActionPerformed(evt);
            }
        });
        quickToolBar.add(clearFormattingQuick);

        changeColorQuickBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/color.png"))); // NOI18N
        changeColorQuickBtn.setToolTipText("Change Text Color");
        changeColorQuickBtn.setFocusable(false);
        changeColorQuickBtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        changeColorQuickBtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        changeColorQuickBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeColorQuickBtnActionPerformed(evt);
            }
        });
        quickToolBar.add(changeColorQuickBtn);
        quickToolBar.add(filler1);

        jLabel1.setText("Font");
        quickToolBar.add(jLabel1);
        quickToolBar.add(filler2);

        fontDesign.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        fontDesign.setMinimumSize(new java.awt.Dimension(40, 20));
        fontDesign.setPreferredSize(new java.awt.Dimension(40, 20));
        fontDesign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontDesignActionPerformed(evt);
            }
        });
        quickToolBar.add(fontDesign);
        quickToolBar.add(jSeparator1);
        quickToolBar.add(filler3);

        jLabel2.setText("Size");
        quickToolBar.add(jLabel2);
        quickToolBar.add(filler4);

        fontSize.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "12", "16", "20", "24", "28", "32", "36", "40", "44", "48", "52", "56", "60", "64", "68", "72" }));
        fontSize.setToolTipText("Text Size");
        fontSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontSizeActionPerformed(evt);
            }
        });
        quickToolBar.add(fontSize);
        quickToolBar.add(jSeparator2);
        quickToolBar.add(filler5);

        searchButtonItem.setText("Search");
        searchButtonItem.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchButtonItem.setFocusable(false);
        searchButtonItem.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        searchButtonItem.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        searchButtonItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonItemActionPerformed(evt);
            }
        });
        quickToolBar.add(searchButtonItem);
        quickToolBar.add(filler6);

        clearSearch.setText("Clear");
        clearSearch.setToolTipText("Clear Search");
        clearSearch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        clearSearch.setFocusable(false);
        clearSearch.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearSearch.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                clearSearchMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                clearSearchMouseExited(evt);
            }
        });
        clearSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearSearchActionPerformed(evt);
            }
        });
        quickToolBar.add(clearSearch);
        quickToolBar.add(filler7);

        searchTextfield.setMaximumSize(new java.awt.Dimension(80000, 500));
        quickToolBar.add(searchTextfield);
        quickToolBar.add(filler9);

        jTextPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(jTextPane1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addComponent(quickToolBar, javax.swing.GroupLayout.DEFAULT_SIZE, 865, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(quickToolBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE))
        );

        fileMenu.setText("File");

        newFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        newFile.setText("New");
        newFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileActionPerformed(evt);
            }
        });
        fileMenu.add(newFile);

        openFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        openFile.setText("Open");
        openFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileActionPerformed(evt);
            }
        });
        fileMenu.add(openFile);

        saveFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveFile.setText("Save");
        saveFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveFile);

        saveAsFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        saveAsFile.setText("Save As");
        saveAsFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveAsFile);

        PrintFile.setText("Print");
        fileMenu.add(PrintFile);

        exitFile.setText("Exit");
        exitFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitFileActionPerformed(evt);
            }
        });
        fileMenu.add(exitFile);

        jMenuBar1.add(fileMenu);

        editMenu.setText("Edit");

        undoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        undoMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Undo16.png"))); // NOI18N
        undoMenuItem.setText("Undo");
        undoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(undoMenuItem);

        redoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        redoMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Redo16.png"))); // NOI18N
        redoMenuItem.setText("Redo");
        redoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(redoMenuItem);

        cutText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        cutText.setText("Cut");
        cutText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextActionPerformed(evt);
            }
        });
        editMenu.add(cutText);

        copyText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        copyText.setText("Copy");
        copyText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextActionPerformed(evt);
            }
        });
        editMenu.add(copyText);

        pasteText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        pasteText.setText("Paste");
        pasteText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextActionPerformed(evt);
            }
        });
        editMenu.add(pasteText);

        selectAllMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        selectAllMenuItem.setText("Select All");
        selectAllMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectAllMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(selectAllMenuItem);

        jMenuBar1.add(editMenu);

        insertMenu.setText("Insert");

        insertImageMenuItem.setText("Image");
        insertImageMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertImageMenuItemActionPerformed(evt);
            }
        });
        insertMenu.add(insertImageMenuItem);

        jMenuBar1.add(insertMenu);

        formatMenu.setText("Format");

        fontEditMenu.setText("Text");

        fontBoldMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        fontBoldMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/bold.png"))); // NOI18N
        fontBoldMenuItem.setText("Bold");
        fontEditMenu.add(fontBoldMenuItem);

        fontItalicMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        fontItalicMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/italic.png"))); // NOI18N
        fontItalicMenuItem.setText("Italic");
        fontEditMenu.add(fontItalicMenuItem);

        fontUnderlineMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        fontUnderlineMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/underline.png"))); // NOI18N
        fontUnderlineMenuItem.setText("Underline");
        fontEditMenu.add(fontUnderlineMenuItem);

        fontStrikethroughMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.SHIFT_MASK));
        fontStrikethroughMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/strikethrough.png"))); // NOI18N
        fontStrikethroughMenuItem.setText("Strikethrough");
        fontEditMenu.add(fontStrikethroughMenuItem);

        capitalizationMenu.setText("Capitalization");

        lowercaseMenuItem.setText("lowercase");
        capitalizationMenu.add(lowercaseMenuItem);

        uppercaseMenuItem.setText("UPPERCASE");
        capitalizationMenu.add(uppercaseMenuItem);

        fontEditMenu.add(capitalizationMenu);

        formatMenu.add(fontEditMenu);

        fontColorMenu.setText("Color");

        fontHighlightColorMenuItem.setText("Highlight Color");
        fontHighlightColorMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontHighlightColorMenuItemActionPerformed(evt);
            }
        });
        fontColorMenu.add(fontHighlightColorMenuItem);

        formatMenu.add(fontColorMenu);

        clearFormatting.setText("Clear Formatting");
        clearFormatting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearFormattingActionPerformed(evt);
            }
        });
        formatMenu.add(clearFormatting);

        jMenuBar1.add(formatMenu);

        toolMenu.setText("Tools");

        wordCounterMenuItem.setText("Word Counter");
        wordCounterMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wordCounterMenuItemActionPerformed(evt);
            }
        });
        toolMenu.add(wordCounterMenuItem);

        jMenuBar1.add(toolMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showSaveDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();

            HTMLEditorKit kit = new HTMLEditorKit();

            BufferedOutputStream out;

            try {
                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            } catch (BadLocationException e){

            }
        }
    }//GEN-LAST:event_saveFileActionPerformed

    private void saveFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileQuickButtonActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showSaveDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();

            HTMLEditorKit kit = new HTMLEditorKit();

            BufferedOutputStream out;

            try {
                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            } catch (BadLocationException e){

            }
        }
    }//GEN-LAST:event_saveFileQuickButtonActionPerformed

    private void cutTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextQuickButtonActionPerformed
        //Logan's feature
        jTextPane1.cut();
    }//GEN-LAST:event_cutTextQuickButtonActionPerformed

    private void changeColorQuickBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeColorQuickBtnActionPerformed
        //Sarmad's feature
        int start = jTextPane1.getSelectionStart();
        int end = jTextPane1.getSelectionEnd();
        int selectedLength = end-start;
        StyledDocument style = jTextPane1.getStyledDocument();
        AttributeSet oldset = style.getCharacterElement(end-1).getAttributes();
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet s = sc.addAttribute(oldset, StyleConstants.Foreground, JColorChooser.showDialog(this,"Select Text Color", clrCrnt));
        style.setCharacterAttributes(start, selectedLength, s, true);
    }//GEN-LAST:event_changeColorQuickBtnActionPerformed

    private void fontDesignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontDesignActionPerformed
        //Sarmad's feature
        fontDesign.setFocusable(false);
        String style = new String(fontDesign.getSelectedItem().toString());
        Action action = new StyledEditorKit.FontFamilyAction("Font size", style);
        action.actionPerformed(null);
    }//GEN-LAST:event_fontDesignActionPerformed

    private void fontSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontSizeActionPerformed
        //Sarmad's feature
        fontSize.setFocusable(false);
        Integer value = Integer.parseInt(fontSize.getSelectedItem().toString());
        Action action = new StyledEditorKit.FontSizeAction("Font size", value);
        action.actionPerformed(null);
    }//GEN-LAST:event_fontSizeActionPerformed

    private void newFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileQuickButtonActionPerformed
        //Sarmad's feature
        jTextPane1.setText("");
        setTitle(fileName);
    }//GEN-LAST:event_newFileQuickButtonActionPerformed

    private void newFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileActionPerformed
        //Sarmad's feature
        jTextPane1.setText("");
        setTitle(fileName);
    }//GEN-LAST:event_newFileActionPerformed

    private void copyTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextQuickButtonActionPerformed
        //Logan's feature
        jTextPane1.copy();
    }//GEN-LAST:event_copyTextQuickButtonActionPerformed

    private void pasteTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextQuickButtonActionPerformed
        //Logan's feature
        jTextPane1.paste();
    }//GEN-LAST:event_pasteTextQuickButtonActionPerformed

    private void cutTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextActionPerformed
        //Logan's feature
        jTextPane1.cut();
    }//GEN-LAST:event_cutTextActionPerformed

    private void copyTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextActionPerformed
        //Logan's feature
        jTextPane1.copy();
    }//GEN-LAST:event_copyTextActionPerformed

    private void pasteTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextActionPerformed
        //Logan's feature
        jTextPane1.paste();
    }//GEN-LAST:event_pasteTextActionPerformed

    private void wordCounterMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wordCounterMenuItemActionPerformed
        //Xi's feature
        String text = jTextPane1.getText();
        JOptionPane.showMessageDialog(this,"Total words: "+ new StringTokenizer(text).countTokens()); 
    }//GEN-LAST:event_wordCounterMenuItemActionPerformed

    private void undoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoMenuItemActionPerformed
        //Logan's feature
        undoManager.undo();
    }//GEN-LAST:event_undoMenuItemActionPerformed

    private void redoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoMenuItemActionPerformed
        //Logan's feature
        undoManager.redo();
    }//GEN-LAST:event_redoMenuItemActionPerformed

    private void openFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileQuickButtonActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showOpenDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            File file = chooser.getSelectedFile();

            jTextPane1.setEditorKit(new HTMLEditorKit());

            try {

            FileReader reader = new FileReader(file);

            jTextPane1.read(reader, file);

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            }
        }
    }//GEN-LAST:event_openFileQuickButtonActionPerformed

    private void openFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showOpenDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            File file = chooser.getSelectedFile();

            jTextPane1.setEditorKit(new HTMLEditorKit());

            try {

            FileReader reader = new FileReader(file);

            jTextPane1.read(reader, file);

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            }
        }
    }//GEN-LAST:event_openFileActionPerformed

    private void saveAsFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showSaveDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();

            HTMLEditorKit kit = new HTMLEditorKit();

            BufferedOutputStream out;

            try {
                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            } catch (BadLocationException e){

            }
        }
    }//GEN-LAST:event_saveAsFileActionPerformed

    private void exitFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitFileActionPerformed
        // Julia's feature
        System.exit(0);
    }//GEN-LAST:event_exitFileActionPerformed

    private void searchButtonItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonItemActionPerformed
        // Xi's feature
        if(searchTextfield.getText().equals("")){        
        }
        else
        highlight(jTextPane1, searchTextfield.getText());
        
    }//GEN-LAST:event_searchButtonItemActionPerformed

    private void insertImageMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertImageMenuItemActionPerformed
        // Julia's feature
        insertActionPerformed();
    }//GEN-LAST:event_insertImageMenuItemActionPerformed

    private void undoQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoQuickButtonActionPerformed
        // Logan's feature
        undoManager.undo();
    }//GEN-LAST:event_undoQuickButtonActionPerformed

    private void redoQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoQuickButtonActionPerformed
        //Logan's feature
        undoManager.redo();
    }//GEN-LAST:event_redoQuickButtonActionPerformed

    private void selectAllMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectAllMenuItemActionPerformed
        // Julia's feature
        jTextPane1.selectAll();
    }//GEN-LAST:event_selectAllMenuItemActionPerformed

    private void clearFormattingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearFormattingActionPerformed
        // Julia's feature
        int start = jTextPane1.getSelectionStart();
        Font font = new Font("Tahoma", Font.PLAIN, 11);
        setJTextPaneFont(jTextPane1, font, Color.black, start);
    }//GEN-LAST:event_clearFormattingActionPerformed

    private void clearSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearSearchActionPerformed
        // Julia's feature
        searchTextfield.setText("");
        removeHighlights(jTextPane1);
    }//GEN-LAST:event_clearSearchActionPerformed

    private void clearSearchMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearSearchMouseEntered
        // Julia's feature
        clearSearch.setForeground(Color.WHITE);
        clearSearch.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_clearSearchMouseEntered

    private void clearSearchMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearSearchMouseExited
        // Julia's feature
        clearSearch.setForeground(Color.BLACK);
        clearSearch.setBackground(UIManager.getColor("control"));
    }//GEN-LAST:event_clearSearchMouseExited

    private void clearFormattingQuickActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearFormattingQuickActionPerformed
        // Julia's feature
        int start = jTextPane1.getSelectionStart();
        Font font = new Font("Tahoma", Font.PLAIN, 11);
        setJTextPaneFont(jTextPane1, font, Color.black, start);
    }//GEN-LAST:event_clearFormattingQuickActionPerformed

    private void highlightQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_highlightQuickButtonActionPerformed
      
         int start = jTextPane1.getSelectionStart();
        int end = jTextPane1.getSelectionEnd();
        int selectedLength =end-start;
        StyledDocument style = jTextPane1.getStyledDocument();
        AttributeSet oldset =style.getCharacterElement(end-1).getAttributes();
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet s = sc.addAttribute(oldset, StyleConstants.Background,JColorChooser.showDialog(this,"Select the highlight color", clrCrnt) );
        style.setCharacterAttributes(start, selectedLength, s, true);
        
        
       /* addHighlight(int start,
                  int end,
                  Highlighter.HighlightPainter p)
                    throws BadLocationException
       */
    }//GEN-LAST:event_highlightQuickButtonActionPerformed

    private void clearHighlightQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearHighlightQuickButtonActionPerformed
        int start =  jTextPane1.getSelectionStart();
        int end = jTextPane1.getSelectionEnd();
        int selectedLength = end - start;
        StyledDocument style = jTextPane1.getStyledDocument();
        AttributeSet oldest = style.getCharacterElement(end-1).getAttributes();
        StyleContext sc = StyleContext.getDefaultStyleContext();
        Color backgroundClr = jTextPane1.getBackground();
        AttributeSet s =sc.addAttribute(oldest, StyleConstants.Background, backgroundClr);
        style.setCharacterAttributes(start, selectedLength, s, true);
    }//GEN-LAST:event_clearHighlightQuickButtonActionPerformed

    private void fontHighlightColorMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontHighlightColorMenuItemActionPerformed
       
          Color newColor =JColorChooser.showDialog(this,"Select Text Color", clrhighlit);        
          highlightColor = newColor;    
        
    }//GEN-LAST:event_fontHighlightColorMenuItemActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScribPadGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem PrintFile;
    private javax.swing.JButton boldQuickButton;
    private javax.swing.JMenu capitalizationMenu;
    private javax.swing.JButton changeColorQuickBtn;
    private javax.swing.JMenuItem clearFormatting;
    private javax.swing.JButton clearFormattingQuick;
    private javax.swing.JButton clearHighlightQuickButton;
    private javax.swing.JButton clearSearch;
    private javax.swing.JMenuItem copyText;
    private javax.swing.JButton copyTextQuickButton;
    private javax.swing.JMenuItem cutText;
    private javax.swing.JButton cutTextQuickButton;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitFile;
    private javax.swing.JMenu fileMenu;
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.Box.Filler filler3;
    private javax.swing.Box.Filler filler4;
    private javax.swing.Box.Filler filler5;
    private javax.swing.Box.Filler filler6;
    private javax.swing.Box.Filler filler7;
    private javax.swing.Box.Filler filler9;
    private javax.swing.JMenuItem fontBoldMenuItem;
    private javax.swing.JMenu fontColorMenu;
    private javax.swing.JComboBox<String> fontDesign;
    private javax.swing.JMenu fontEditMenu;
    private javax.swing.JMenuItem fontHighlightColorMenuItem;
    private javax.swing.JMenuItem fontItalicMenuItem;
    private javax.swing.JComboBox<String> fontSize;
    private javax.swing.JMenuItem fontStrikethroughMenuItem;
    private javax.swing.JMenuItem fontUnderlineMenuItem;
    private javax.swing.JMenu formatMenu;
    private javax.swing.JButton highlightQuickButton;
    private javax.swing.JMenuItem insertImageMenuItem;
    private javax.swing.JMenu insertMenu;
    private javax.swing.JButton italicQuickButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JMenuItem lowercaseMenuItem;
    private javax.swing.JMenuItem newFile;
    private javax.swing.JButton newFileQuickButton;
    private javax.swing.JMenuItem openFile;
    private javax.swing.JButton openFileQuickButton;
    private javax.swing.JMenuItem pasteText;
    private javax.swing.JButton pasteTextQuickButton;
    private javax.swing.JToolBar quickToolBar;
    private javax.swing.JMenuItem redoMenuItem;
    private javax.swing.JButton redoQuickButton;
    private javax.swing.JMenuItem saveAsFile;
    private javax.swing.JMenuItem saveFile;
    private javax.swing.JButton saveFileQuickButton;
    private javax.swing.JButton searchButtonItem;
    private javax.swing.JTextField searchTextfield;
    private javax.swing.JMenuItem selectAllMenuItem;
    private javax.swing.JButton strikethroughQuickButton;
    private javax.swing.JMenu toolMenu;
    private javax.swing.JButton underlineQuickButton;
    private javax.swing.JMenuItem undoMenuItem;
    private javax.swing.JButton undoQuickButton;
    private javax.swing.JMenuItem uppercaseMenuItem;
    private javax.swing.JMenuItem wordCounterMenuItem;
    // End of variables declaration//GEN-END:variables
    // java undo and redo action classes

    // Logan's classes 
    class UndoHandler implements UndoableEditListener
    {

    /**
    * Messaged when the Document has created an edit, the edit is added to
    * <code>undoManager</code>, an instance of UndoManager.
    */
        @Override
        public void undoableEditHappened(UndoableEditEvent e)
        {
            undoManager.addEdit(e.getEdit());
            undoAction.update();
            redoAction.update();
        }
    }

    class UndoAction extends AbstractAction
    {
        public UndoAction()
        {
            super("Undo");
            setEnabled(false);
        }

        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                undoManager.undo();
            }
            catch (CannotUndoException ex)
            {
                // TODO deal with this
                //ex.printStackTrace();
            }
            
            update();
            redoAction.update();
    }

    protected void update()
    {
        if (undoManager.canUndo())
        {
            setEnabled(true);
            putValue(Action.NAME, undoManager.getUndoPresentationName());
        }
        else
        {
            setEnabled(false);
            putValue(Action.NAME, "Undo");
        }
    }
}

    class RedoAction extends AbstractAction
    {
          public RedoAction()
          {
            super("Redo");
            setEnabled(false);
          }

          @Override
          public void actionPerformed(ActionEvent e)
          {
            try
            {
              undoManager.redo();
            }
            catch (CannotRedoException ex)
            {

            }
            update();
            undoAction.update();
          }

          protected void update()
          {
            if (undoManager.canRedo())
            {
              putValue(Action.NAME, undoManager.getRedoPresentationName());
              setEnabled(true);
            }
            else
            {
              setEnabled(false);
              putValue(Action.NAME, "Redo");
            }
          }
    }
    // End of Logan's classes
    // Start of insert images (Julia)
    private void insertActionPerformed()
    {
        JFileChooser jf=new JFileChooser();
        
        // Show open dialog
        int option=jf.showOpenDialog(this);
        
            // If user chooses to insert..
            if(option==JFileChooser.APPROVE_OPTION)
            {
                File file=jf.getSelectedFile();
                    if(isImage(file))
                    {
                        // Insert the icon
                        jTextPane1.insertIcon(new ImageIcon(file.getAbsolutePath()));
                    }
                    else
                    // Show an error message, if not an image
                    JOptionPane.showMessageDialog(this,"The file is not an image.","Not Image",JOptionPane.ERROR_MESSAGE);
            }
    }
    
    private boolean isImage(File file)
    {
        String name=file.getName();
            return name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg") || name.endsWith(".gif");
    }
    // End of insert images (Julia)
    // Start of clear formatting (Julia)
    public void setJTextPaneFont(JTextPane jtp, Font font, Color c, int start) {
        // Start with the current input attributes for the JTextPane. This
        // should ensure that we do not wipe out any existing attributes
        // (such as alignment or other paragraph attributes) currently
        // set on the text area.
        MutableAttributeSet attrs = jtp.getInputAttributes();

        // Set the font family, size, and style, based on properties of the Font object.
        StyleConstants.setFontFamily(attrs, font.getFamily());
        StyleConstants.setFontSize(attrs, font.getSize());
        StyleConstants.setItalic(attrs, false);
        StyleConstants.setBold(attrs, false);
        StyleConstants.setUnderline(attrs, false);
        StyleConstants.setStrikeThrough(attrs, false);
        // Set the font color
        StyleConstants.setForeground(attrs, c);

        // Retrieve the pane's document object
        StyledDocument doc = jtp.getStyledDocument();

        // Replace the style for the entire document.
        doc.setCharacterAttributes(start, jTextPane1.getSelectedText().length(), attrs, true);
    }
    // End of clear formatting (Julia)
}
