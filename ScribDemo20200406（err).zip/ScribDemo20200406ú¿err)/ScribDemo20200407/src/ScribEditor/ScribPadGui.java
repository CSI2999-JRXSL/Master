/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JColorChooser;
import javax.swing.text.AttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.text.StyledEditorKit;
import javax.swing.KeyStroke;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.Document;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import java.awt.Event;
import java.awt.KeyboardFocusManager;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.JFileChooser;
import javax.swing.text.BadLocationException;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.JOptionPane;
import java.util.StringTokenizer;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.UIManager;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.MessageFormat;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.SwingUtilities;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.WindowConstants;
import javax.swing.ButtonGroup;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.TabSet;
import javax.swing.text.TabStop;
import java.util.Map;
import java.util.HashMap;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.net.URI;
import javax.swing.text.Style;
/**
 *
 * @author Xi Song, Julia Wang, Robertson Brinker, Sarmad Barya, Logan Collier
 */
public class ScribPadGui extends javax.swing.JFrame implements MouseListener{

    //Undo and redo
    private Document[] editDocument = new Document[100];
    protected UndoHandler[] undoHandler = new UndoHandler[100];
    protected UndoManager[] undoManager = new UndoManager[100];
    private UndoAction[] undoAction = new UndoAction[100];
    private RedoAction[] redoAction = new RedoAction[100];
    private Document editDocumentGlobal;
    protected UndoHandlerGlobal undoHandlerGlobal = new UndoHandlerGlobal();;
    protected UndoManager undoManagerGlobal = new UndoManager();;
    private UndoActionGlobal undoActionGlobal = null;
    private RedoActionGlobal redoActionGlobal = null;
    private Color highlightColor = Color.YELLOW;
    //hyperlink added
    private JTextPane jTextPane1,jTextPane2;
    private StyledDocument doc;
   
    
    private JTextPane activePane;
    /**
     * Creates new form ScribPadGui
     */
    String fileName;
    Color clrCrnt;
    Color fontColor = Color.BLACK;
    Color clrhighlit;
    int value = 11;
    // Save file variables
    int numSavedSpaces = 0;
    boolean saved = true;
    boolean saveAsDone = false;
    boolean multiFilesChosen = false;
    boolean sameLocation = false;
    boolean splitsSaved = true;
    BufferedOutputStream oldOut = null;
    File f[] = new File[100];
    File file;
    JFileChooser saveChooser = new JFileChooser();
    String baseName = "";
    
    //Start of Right-Click Code (Robertson)
    //Variable Declaration for Workspaces
    int indVWS = 0;
    javax.swing.JScrollPane[] scrollArrV = new javax.swing.JScrollPane[100];
    javax.swing.JTextPane[] textArrV = new javax.swing.JTextPane[100];
    // Count number of splitworkspaces
    int horizWorkspace = 0;
    int vertWorkspace = 0;
    
    //set the variables for header and footer
    protected MessageFormat header = null; 
    protected MessageFormat footer = null;
    
    public ScribPadGui() {
        initComponents();
        jTextPane1.requestFocusInWindow();
        // Start of line spacing (Robertson)
        LineSpacer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "1.15", "1.5", "2"}));
        LineSpacer.setToolTipText("Line Space");
        // End of line spacing (Robertson)
        // Start of set application icon (Julia)
        this.setIconImage(new ImageIcon(getClass().getResource("/ScribEditor/icons/ScribIcon.png")).getImage());
        // End of set application icon (Julia)
        // Start of font styling (Sarmad)
        Dimension layout = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(layout.width/2 - this.getWidth()/2, layout.height/2 - this.getHeight()/2);
        this.setSize(1200,660);

        GraphicsEnvironment gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontNames = gEnv.getAvailableFontFamilyNames();
        ComboBoxModel model = new DefaultComboBoxModel(fontNames);
        fontDesign.setModel(model);
        // End of font styling (Sarmad)
        // Start of Bolding, Italicising, Underlining, Strikethrough (Robertson)
        fontBoldMenuItem.addActionListener(new StyledEditorKit.BoldAction());
        fontItalicMenuItem.addActionListener(new StyledEditorKit.ItalicAction());
        fontUnderlineMenuItem.addActionListener(new StyledEditorKit.UnderlineAction());
        fontStrikethroughMenuItem.addActionListener(new StrikethroughAction());
        boldQuickButton.addActionListener(new StyledEditorKit.BoldAction());
        italicQuickButton.addActionListener(new StyledEditorKit.ItalicAction());
        underlineQuickButton.addActionListener(new StyledEditorKit.UnderlineAction());
        strikethroughQuickButton.addActionListener(new StrikethroughAction());
        // End of Bolding, Italicising, Underlining, Strikethrough (Robertson)
        // Start of Uppercase/Lowercase (Robertson)
        lowercaseMenuItem.addActionListener(new LowercaseAction());
        uppercaseMenuItem.addActionListener(new UppercaseAction());
        // End of Uppercase/Lowercase (Robertson)
        // Start of splittable workspaces (Robertson)
        scrollArrV[0] = jScrollPane1;
        textArrV[0] = jTextPane1;
        // End of splittable workspaces (Robertson)
        globalHistoryRadio.setSelected(false);
        ButtonGroup group = new ButtonGroup();
        group.add(globalHistoryRadio);
        group.add(localHistoryRadio);
        // Undo/Redo (Logan)
        undoRedoInitLocal(jTextPane1, 0);
        undoRedoInitGlobal(jTextPane1);
        // End of Undo/Redo (Logan)
        // Start of alignment (Sarmad)
        formatLeft.addActionListener(new StyledEditorKit.AlignmentAction("", StyleConstants.ALIGN_LEFT));
        formatCenter.addActionListener(new StyledEditorKit.AlignmentAction("", StyleConstants.ALIGN_CENTER));
        formatRight.addActionListener(new StyledEditorKit.AlignmentAction("", StyleConstants.ALIGN_RIGHT));
        leftAlignMenuItem.addActionListener(new StyledEditorKit.AlignmentAction("", StyleConstants.ALIGN_LEFT));
        centerAlignMenuItem.addActionListener(new StyledEditorKit.AlignmentAction("", StyleConstants.ALIGN_CENTER));
        rightAlignMenuItem.addActionListener(new StyledEditorKit.AlignmentAction("", StyleConstants.ALIGN_RIGHT));
        // End of alignment (Sarmad)
        // Start of active pane border and persistent font attributes (Julia)
        persistentFontFamily.setSelected(false);
        persistentFontSize.setSelected(false);
        persistentFontColor.setSelected(false);
        persistentHighlight.setSelected(false);
        persistentBold.setSelected(false);
        persistentItalic.setSelected(false);
        persistentUnderline.setSelected(false);
        persistentStrikethrough.setSelected(false);
        persistentLowercase.setSelected(false);
        persistentUppercase.setSelected(false);
        persistentClear.setSelected(false);
        disPaneBorder.setSelected(false);
        paneListeners(0);
        // End of active pane border and persistent font attributes (Julia)
        //
        //
        //Begin of the Hyperlink function
        
        
        //End of the hyperlink function
        //
        //
    }
    
    //Begin of "Search function" edited by Xi
    class MyHighlightPainter extends DefaultHighlighter.DefaultHighlightPainter{
          public MyHighlightPainter(Color color){
              super(color);
          }
           
      }
    
        
         Highlighter.HighlightPainter myHighlightPainter = new MyHighlightPainter(Color.cyan);
         
         
         public void removeHighlights(JTextComponent textComp){
             Highlighter hilite = textComp.getHighlighter();
             Highlighter.Highlight[] hilites = hilite.getHighlights();
             
             for(int i=0; i<hilites.length;i++){
                 if(hilites[i].getPainter() instanceof MyHighlightPainter){
                     hilite.removeHighlight(hilites[i]);
                 }
             }
         }
         
         public void highlight(JTextComponent textComp, String pattern){
             
             removeHighlights(textComp);
             
             try{
                 
                 Highlighter hilite = textComp.getHighlighter();
                 Document doc =textComp.getDocument();
                 String text = doc.getText(0, doc.getLength());
                 int pos=0;
                 
                 while((pos=text.toUpperCase().indexOf(pattern.toUpperCase(),pos))>=0){
                     hilite.addHighlight(pos, pos+pattern.length(), myHighlightPainter);
                     pos += pattern.length();
                 }
             }
             catch(Exception e){
                 
             }
             
         }
         //End of "Search Function" edited by Xi

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        HeaderFooterFrame = new javax.swing.JFrame();
        jLabel1 = new javax.swing.JLabel();
        headerLabel = new javax.swing.JLabel();
        footerLabel = new javax.swing.JLabel();
        headFootOK = new javax.swing.JButton();
        headFootCancel = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        footerjTextPane = new javax.swing.JTextPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        headerjTextPane = new javax.swing.JTextPane();
        jPanel1 = new javax.swing.JPanel();
        quickToolBar = new javax.swing.JToolBar();
        undoQuickButton = new javax.swing.JButton();
        redoQuickButton = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JToolBar.Separator();
        newFileQuickButton = new javax.swing.JButton();
        openFileQuickButton = new javax.swing.JButton();
        saveFileQuickButton = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JToolBar.Separator();
        copyTextQuickButton = new javax.swing.JButton();
        cutTextQuickButton = new javax.swing.JButton();
        pasteTextQuickButton = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JToolBar.Separator();
        highlightQuickButton = new javax.swing.JButton();
        clearHighlightQuickButton = new javax.swing.JButton();
        clearFormattingQuick = new javax.swing.JButton();
        hyperlinkQuickButton = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JToolBar.Separator();
        boldQuickButton = new javax.swing.JButton();
        italicQuickButton = new javax.swing.JButton();
        strikethroughQuickButton = new javax.swing.JButton();
        underlineQuickButton = new javax.swing.JButton();
        changeColorQuickBtn = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        formatLeft = new javax.swing.JButton();
        formatCenter = new javax.swing.JButton();
        formatRight = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(8, 1), new java.awt.Dimension(8, 1), new java.awt.Dimension(8, 1));
        fontDesign = new javax.swing.JComboBox<String>();
        filler3 = new javax.swing.Box.Filler(new java.awt.Dimension(8, 1), new java.awt.Dimension(8, 1), new java.awt.Dimension(8, 1));
        fontSize = new javax.swing.JComboBox<String>();
        filler8 = new javax.swing.Box.Filler(new java.awt.Dimension(8, 1), new java.awt.Dimension(8, 1), new java.awt.Dimension(8, 1));
        LineSpacer = new javax.swing.JComboBox<String>();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        filler5 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        searchButtonItem = new javax.swing.JButton();
        filler6 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        clearSearch = new javax.swing.JButton();
        filler7 = new javax.swing.Box.Filler(new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1), new java.awt.Dimension(4, 1));
        searchTextfield = new javax.swing.JTextField();
        filler9 = new javax.swing.Box.Filler(new java.awt.Dimension(30, 1), new java.awt.Dimension(30, 1), new java.awt.Dimension(30, 1));
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        newFile = new javax.swing.JMenuItem();
        openFile = new javax.swing.JMenuItem();
        saveFile = new javax.swing.JMenuItem();
        saveAsFile = new javax.swing.JMenuItem();
        printFile = new javax.swing.JMenuItem();
        exitFile = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        undoMenuItem = new javax.swing.JMenuItem();
        redoMenuItem = new javax.swing.JMenuItem();
        cutText = new javax.swing.JMenuItem();
        copyText = new javax.swing.JMenuItem();
        pasteText = new javax.swing.JMenuItem();
        selectAllMenuItem = new javax.swing.JMenuItem();
        insertMenu = new javax.swing.JMenu();
        insertImageMenuItem = new javax.swing.JMenuItem();
        loremIpsumMenuItem = new javax.swing.JMenuItem();
        formatMenu = new javax.swing.JMenu();
        fontEditMenu = new javax.swing.JMenu();
        fontBoldMenuItem = new javax.swing.JMenuItem();
        fontItalicMenuItem = new javax.swing.JMenuItem();
        fontUnderlineMenuItem = new javax.swing.JMenuItem();
        fontStrikethroughMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        incSizeMenuItem = new javax.swing.JMenuItem();
        decSizeMenuItem = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JPopupMenu.Separator();
        capitalizationMenu = new javax.swing.JMenu();
        lowercaseMenuItem = new javax.swing.JMenuItem();
        uppercaseMenuItem = new javax.swing.JMenuItem();
        alignAndIndentMenu = new javax.swing.JMenu();
        leftAlignMenuItem = new javax.swing.JMenuItem();
        centerAlignMenuItem = new javax.swing.JMenuItem();
        rightAlignMenuItem = new javax.swing.JMenuItem();
        fontHighlightColorMenuItem = new javax.swing.JMenuItem();
        headerAndFooterMenuItem = new javax.swing.JMenuItem();
        clearFormatting = new javax.swing.JMenuItem();
        toolMenu = new javax.swing.JMenu();
        wordCounterMenuItem = new javax.swing.JMenuItem();
        btnAddVerticalWorkSpace = new javax.swing.JMenuItem();
        settingsMenu = new javax.swing.JMenu();
        disPaneBorder = new javax.swing.JCheckBoxMenuItem();
        persistentOptions = new javax.swing.JMenu();
        persistentClear = new javax.swing.JCheckBoxMenuItem();
        persistentFontFamily = new javax.swing.JCheckBoxMenuItem();
        persistentFontSize = new javax.swing.JCheckBoxMenuItem();
        persistentFontColor = new javax.swing.JCheckBoxMenuItem();
        persistentHighlight = new javax.swing.JCheckBoxMenuItem();
        persistentTextMenu = new javax.swing.JMenu();
        persistentBold = new javax.swing.JCheckBoxMenuItem();
        persistentItalic = new javax.swing.JCheckBoxMenuItem();
        persistentUnderline = new javax.swing.JCheckBoxMenuItem();
        persistentStrikethrough = new javax.swing.JCheckBoxMenuItem();
        persistentLowercase = new javax.swing.JCheckBoxMenuItem();
        persistentUppercase = new javax.swing.JCheckBoxMenuItem();
        globalHistoryRadio = new javax.swing.JRadioButtonMenuItem();
        localHistoryRadio = new javax.swing.JRadioButtonMenuItem();

        HeaderFooterFrame.setMinimumSize(new java.awt.Dimension(240, 240));
        HeaderFooterFrame.setSize(new java.awt.Dimension(370, 350));

        jLabel1.setText("Set Header and Footer for printing");

        headerLabel.setText("Header:");

        footerLabel.setText("Footer:");

        headFootOK.setText("OK");
        headFootOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                headFootOKActionPerformed(evt);
            }
        });

        headFootCancel.setText("Cancel");
        headFootCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                headFootCancelActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(footerjTextPane);

        jScrollPane3.setViewportView(headerjTextPane);

        javax.swing.GroupLayout HeaderFooterFrameLayout = new javax.swing.GroupLayout(HeaderFooterFrame.getContentPane());
        HeaderFooterFrame.getContentPane().setLayout(HeaderFooterFrameLayout);
        HeaderFooterFrameLayout.setHorizontalGroup(
            HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HeaderFooterFrameLayout.createSequentialGroup()
                .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(HeaderFooterFrameLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(HeaderFooterFrameLayout.createSequentialGroup()
                                .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(footerLabel)
                                    .addComponent(headerLabel))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(HeaderFooterFrameLayout.createSequentialGroup()
                                .addGap(101, 101, 101)
                                .addComponent(headFootOK, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(headFootCancel))))
                    .addGroup(HeaderFooterFrameLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jLabel1)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        HeaderFooterFrameLayout.setVerticalGroup(
            HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HeaderFooterFrameLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(headerLabel)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(footerLabel)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(HeaderFooterFrameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(headFootOK)
                    .addComponent(headFootCancel))
                .addContainerGap())
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        quickToolBar.setRollover(true);
        quickToolBar.setAlignmentY(0.5F);

        undoQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Undo.png"))); // NOI18N
        undoQuickButton.setToolTipText("Undo");
        undoQuickButton.setFocusable(false);
        undoQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        undoQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        undoQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(undoQuickButton);

        redoQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Redo.png"))); // NOI18N
        redoQuickButton.setFocusable(false);
        redoQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        redoQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        redoQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(redoQuickButton);
        quickToolBar.add(jSeparator7);

        newFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/newFile1.png"))); // NOI18N
        newFileQuickButton.setToolTipText("New");
        newFileQuickButton.setFocusable(false);
        newFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        newFileQuickButton.setMaximumSize(new java.awt.Dimension(30, 40));
        newFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        newFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(newFileQuickButton);

        openFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/document_open.png"))); // NOI18N
        openFileQuickButton.setToolTipText("Open");
        openFileQuickButton.setFocusable(false);
        openFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        openFileQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        openFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        openFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(openFileQuickButton);

        saveFileQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/save_file.png"))); // NOI18N
        saveFileQuickButton.setToolTipText("Save");
        saveFileQuickButton.setFocusable(false);
        saveFileQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        saveFileQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        saveFileQuickButton.setMinimumSize(new java.awt.Dimension(39, 39));
        saveFileQuickButton.setPreferredSize(new java.awt.Dimension(35, 35));
        saveFileQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        saveFileQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(saveFileQuickButton);
        quickToolBar.add(jSeparator6);

        copyTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/copy.png"))); // NOI18N
        copyTextQuickButton.setToolTipText("Copy");
        copyTextQuickButton.setFocusable(false);
        copyTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        copyTextQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        copyTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        copyTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(copyTextQuickButton);

        cutTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/clipboard_cut.png"))); // NOI18N
        cutTextQuickButton.setToolTipText("Cut");
        cutTextQuickButton.setFocusable(false);
        cutTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cutTextQuickButton.setMaximumSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setMinimumSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setPreferredSize(new java.awt.Dimension(35, 39));
        cutTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cutTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(cutTextQuickButton);

        pasteTextQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/paste.png"))); // NOI18N
        pasteTextQuickButton.setToolTipText("Paste");
        pasteTextQuickButton.setFocusable(false);
        pasteTextQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        pasteTextQuickButton.setMaximumSize(new java.awt.Dimension(39, 40));
        pasteTextQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        pasteTextQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(pasteTextQuickButton);
        quickToolBar.add(jSeparator5);

        highlightQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/highlight_black.png"))); // NOI18N
        highlightQuickButton.setToolTipText("Highlight");
        highlightQuickButton.setFocusable(false);
        highlightQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        highlightQuickButton.setMaximumSize(new java.awt.Dimension(39, 39));
        highlightQuickButton.setMinimumSize(new java.awt.Dimension(39, 39));
        highlightQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        highlightQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                highlightQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(highlightQuickButton);

        clearHighlightQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/clear_highlight_black.png"))); // NOI18N
        clearHighlightQuickButton.setToolTipText("Clear Highlight");
        clearHighlightQuickButton.setFocusable(false);
        clearHighlightQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearHighlightQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearHighlightQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearHighlightQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(clearHighlightQuickButton);

        clearFormattingQuick.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/eraser.png"))); // NOI18N
        clearFormattingQuick.setToolTipText("Clear Formatting");
        clearFormattingQuick.setFocusable(false);
        clearFormattingQuick.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearFormattingQuick.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearFormattingQuick.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearFormattingQuickActionPerformed(evt);
            }
        });
        quickToolBar.add(clearFormattingQuick);

        hyperlinkQuickButton.setText("Hyperlink");
        hyperlinkQuickButton.setFocusable(false);
        hyperlinkQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        hyperlinkQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        hyperlinkQuickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hyperlinkQuickButtonActionPerformed(evt);
            }
        });
        quickToolBar.add(hyperlinkQuickButton);
        quickToolBar.add(jSeparator4);

        boldQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/boldText.png"))); // NOI18N
        boldQuickButton.setToolTipText("Bold Text");
        boldQuickButton.setFocusable(false);
        boldQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        boldQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(boldQuickButton);

        italicQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/italicText.png"))); // NOI18N
        italicQuickButton.setToolTipText("Italicize Text");
        italicQuickButton.setFocusable(false);
        italicQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        italicQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(italicQuickButton);

        strikethroughQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/strikethroughText.png"))); // NOI18N
        strikethroughQuickButton.setToolTipText("Strikethrough Text");
        strikethroughQuickButton.setFocusable(false);
        strikethroughQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        strikethroughQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(strikethroughQuickButton);

        underlineQuickButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/underlineText.png"))); // NOI18N
        underlineQuickButton.setToolTipText("Underline Text");
        underlineQuickButton.setFocusable(false);
        underlineQuickButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        underlineQuickButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(underlineQuickButton);

        changeColorQuickBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/colorText.png"))); // NOI18N
        changeColorQuickBtn.setToolTipText("Change Text Color");
        changeColorQuickBtn.setFocusable(false);
        changeColorQuickBtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        changeColorQuickBtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        changeColorQuickBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeColorQuickBtnActionPerformed(evt);
            }
        });
        quickToolBar.add(changeColorQuickBtn);
        quickToolBar.add(jSeparator3);

        formatLeft.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/align_left.png"))); // NOI18N
        formatLeft.setToolTipText("Left Alignment");
        formatLeft.setFocusable(false);
        formatLeft.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        formatLeft.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(formatLeft);

        formatCenter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/align_center.png"))); // NOI18N
        formatCenter.setToolTipText("Center Alignment");
        formatCenter.setFocusable(false);
        formatCenter.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        formatCenter.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(formatCenter);

        formatRight.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/align_right.png"))); // NOI18N
        formatRight.setToolTipText("Right Alignment");
        formatRight.setFocusable(false);
        formatRight.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        formatRight.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        quickToolBar.add(formatRight);
        quickToolBar.add(filler1);

        fontDesign.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        fontDesign.setToolTipText("Font Family");
        fontDesign.setMinimumSize(new java.awt.Dimension(40, 20));
        fontDesign.setPreferredSize(new java.awt.Dimension(40, 20));
        fontDesign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontDesignActionPerformed(evt);
            }
        });
        quickToolBar.add(fontDesign);
        quickToolBar.add(filler3);

        fontSize.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "12", "16", "20", "24", "28", "32", "36", "40", "44", "48", "52", "56", "60", "64", "68", "72" }));
        fontSize.setToolTipText("Text Size");
        fontSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontSizeActionPerformed(evt);
            }
        });
        quickToolBar.add(fontSize);
        quickToolBar.add(filler8);

        LineSpacer.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        LineSpacer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LineSpacerActionPerformed(evt);
            }
        });
        quickToolBar.add(LineSpacer);
        quickToolBar.add(jSeparator2);
        quickToolBar.add(filler5);

        searchButtonItem.setText("Search");
        searchButtonItem.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchButtonItem.setFocusable(false);
        searchButtonItem.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        searchButtonItem.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        searchButtonItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonItemActionPerformed(evt);
            }
        });
        quickToolBar.add(searchButtonItem);
        quickToolBar.add(filler6);

        clearSearch.setText("Clear");
        clearSearch.setToolTipText("Clear Search");
        clearSearch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        clearSearch.setFocusable(false);
        clearSearch.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clearSearch.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clearSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                clearSearchMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                clearSearchMouseExited(evt);
            }
        });
        clearSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearSearchActionPerformed(evt);
            }
        });
        quickToolBar.add(clearSearch);
        quickToolBar.add(filler7);

        searchTextfield.setMaximumSize(new java.awt.Dimension(80000, 500));
        quickToolBar.add(searchTextfield);
        quickToolBar.add(filler9);

        jTextPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(jTextPane1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 979, Short.MAX_VALUE)
            .addComponent(quickToolBar, javax.swing.GroupLayout.PREFERRED_SIZE, 979, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(quickToolBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE))
        );

        fileMenu.setText("File");

        newFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        newFile.setText("New");
        newFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileActionPerformed(evt);
            }
        });
        fileMenu.add(newFile);

        openFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        openFile.setText("Open");
        openFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileActionPerformed(evt);
            }
        });
        fileMenu.add(openFile);

        saveFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveFile.setText("Save");
        saveFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveFile);

        saveAsFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        saveAsFile.setText("Save As");
        saveAsFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveAsFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveAsFile);

        printFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_MASK));
        printFile.setText("Print");
        printFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printFileActionPerformed(evt);
            }
        });
        fileMenu.add(printFile);

        exitFile.setText("Exit");
        exitFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitFileActionPerformed(evt);
            }
        });
        fileMenu.add(exitFile);

        jMenuBar1.add(fileMenu);

        editMenu.setText("Edit");

        undoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        undoMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Undo16.png"))); // NOI18N
        undoMenuItem.setText("Undo");
        undoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(undoMenuItem);

        redoMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        redoMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/Redo16.png"))); // NOI18N
        redoMenuItem.setText("Redo");
        redoMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(redoMenuItem);

        cutText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        cutText.setText("Cut");
        cutText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextActionPerformed(evt);
            }
        });
        editMenu.add(cutText);

        copyText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        copyText.setText("Copy");
        copyText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextActionPerformed(evt);
            }
        });
        editMenu.add(copyText);

        pasteText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        pasteText.setText("Paste");
        pasteText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextActionPerformed(evt);
            }
        });
        editMenu.add(pasteText);

        selectAllMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        selectAllMenuItem.setText("Select All");
        selectAllMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectAllMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(selectAllMenuItem);

        jMenuBar1.add(editMenu);

        insertMenu.setText("Insert");

        insertImageMenuItem.setText("Image");
        insertImageMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertImageMenuItemActionPerformed(evt);
            }
        });
        insertMenu.add(insertImageMenuItem);

        loremIpsumMenuItem.setText("Lorem Ipsum");
        loremIpsumMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loremIpsumMenuItemActionPerformed(evt);
            }
        });
        insertMenu.add(loremIpsumMenuItem);

        jMenuBar1.add(insertMenu);

        formatMenu.setText("Format");

        fontEditMenu.setText("Text");

        fontBoldMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        fontBoldMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/bold.png"))); // NOI18N
        fontBoldMenuItem.setText("Bold");
        fontEditMenu.add(fontBoldMenuItem);

        fontItalicMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        fontItalicMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/italic.png"))); // NOI18N
        fontItalicMenuItem.setText("Italic");
        fontEditMenu.add(fontItalicMenuItem);

        fontUnderlineMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        fontUnderlineMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/underline.png"))); // NOI18N
        fontUnderlineMenuItem.setText("Underline");
        fontEditMenu.add(fontUnderlineMenuItem);

        fontStrikethroughMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.SHIFT_MASK));
        fontStrikethroughMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ScribEditor/icons/strikethrough.png"))); // NOI18N
        fontStrikethroughMenuItem.setText("Strikethrough");
        fontEditMenu.add(fontStrikethroughMenuItem);
        fontEditMenu.add(jSeparator1);

        incSizeMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_CLOSE_BRACKET, java.awt.event.InputEvent.CTRL_MASK));
        incSizeMenuItem.setText("Increase Size");
        incSizeMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incSizeMenuItemActionPerformed(evt);
            }
        });
        fontEditMenu.add(incSizeMenuItem);

        decSizeMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_OPEN_BRACKET, java.awt.event.InputEvent.CTRL_MASK));
        decSizeMenuItem.setText("Decrease Size");
        decSizeMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                decSizeMenuItemActionPerformed(evt);
            }
        });
        fontEditMenu.add(decSizeMenuItem);
        fontEditMenu.add(jSeparator8);

        capitalizationMenu.setText("Capitalization");

        lowercaseMenuItem.setText("lowercase");
        capitalizationMenu.add(lowercaseMenuItem);

        uppercaseMenuItem.setText("UPPERCASE");
        capitalizationMenu.add(uppercaseMenuItem);

        fontEditMenu.add(capitalizationMenu);

        formatMenu.add(fontEditMenu);

        alignAndIndentMenu.setText("Align & Indent");

        leftAlignMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        leftAlignMenuItem.setText("Left Align");
        alignAndIndentMenu.add(leftAlignMenuItem);

        centerAlignMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        centerAlignMenuItem.setText("Center Align");
        alignAndIndentMenu.add(centerAlignMenuItem);

        rightAlignMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        rightAlignMenuItem.setText("Right Align");
        alignAndIndentMenu.add(rightAlignMenuItem);

        formatMenu.add(alignAndIndentMenu);

        fontHighlightColorMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_MASK));
        fontHighlightColorMenuItem.setText("Set Highlight Color");
        fontHighlightColorMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontHighlightColorMenuItemActionPerformed(evt);
            }
        });
        formatMenu.add(fontHighlightColorMenuItem);

        headerAndFooterMenuItem.setText("Header and Footer");
        headerAndFooterMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                headerAndFooterMenuItemActionPerformed(evt);
            }
        });
        formatMenu.add(headerAndFooterMenuItem);

        clearFormatting.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_K, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        clearFormatting.setText("Clear Formatting");
        clearFormatting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearFormattingActionPerformed(evt);
            }
        });
        formatMenu.add(clearFormatting);

        jMenuBar1.add(formatMenu);

        toolMenu.setText("Tools");

        wordCounterMenuItem.setText("Word Counter");
        wordCounterMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wordCounterMenuItemActionPerformed(evt);
            }
        });
        toolMenu.add(wordCounterMenuItem);

        btnAddVerticalWorkSpace.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_MASK));
        btnAddVerticalWorkSpace.setText("Split Work Space");
        btnAddVerticalWorkSpace.setToolTipText("Type /splithoriz or /splitvert onto the pane then click this menu item.");
        btnAddVerticalWorkSpace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddVerticalWorkSpaceActionPerformed(evt);
            }
        });
        toolMenu.add(btnAddVerticalWorkSpace);

        jMenuBar1.add(toolMenu);

        settingsMenu.setText("Settings");

        disPaneBorder.setSelected(true);
        disPaneBorder.setText("Disable Active Pane Border");
        settingsMenu.add(disPaneBorder);

        persistentOptions.setText("Persistent Options");
        persistentOptions.setToolTipText("Skip clicking buttons and apply text attributes to any selection.");

        persistentClear.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_BACK_QUOTE, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentClear.setSelected(true);
        persistentClear.setText("Clear Formatting");
        persistentOptions.add(persistentClear);

        persistentFontFamily.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentFontFamily.setSelected(true);
        persistentFontFamily.setText("Font Family");
        persistentOptions.add(persistentFontFamily);

        persistentFontSize.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentFontSize.setSelected(true);
        persistentFontSize.setText("Font Size");
        persistentOptions.add(persistentFontSize);

        persistentFontColor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentFontColor.setSelected(true);
        persistentFontColor.setText("Font Color");
        persistentOptions.add(persistentFontColor);

        persistentHighlight.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentHighlight.setSelected(true);
        persistentHighlight.setText("Highlight");
        persistentOptions.add(persistentHighlight);

        persistentTextMenu.setText("Text");

        persistentBold.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_5, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentBold.setSelected(true);
        persistentBold.setText("Bold");
        persistentTextMenu.add(persistentBold);

        persistentItalic.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_6, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentItalic.setSelected(true);
        persistentItalic.setText("Italic");
        persistentTextMenu.add(persistentItalic);

        persistentUnderline.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_7, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentUnderline.setSelected(true);
        persistentUnderline.setText("Underline");
        persistentTextMenu.add(persistentUnderline);

        persistentStrikethrough.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_8, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentStrikethrough.setSelected(true);
        persistentStrikethrough.setText("Strikethrough");
        persistentTextMenu.add(persistentStrikethrough);

        persistentLowercase.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_9, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentLowercase.setSelected(true);
        persistentLowercase.setText("lowercase");
        persistentTextMenu.add(persistentLowercase);

        persistentUppercase.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        persistentUppercase.setSelected(true);
        persistentUppercase.setText("UPPERCASE");
        persistentTextMenu.add(persistentUppercase);

        persistentOptions.add(persistentTextMenu);

        settingsMenu.add(persistentOptions);

        globalHistoryRadio.setSelected(true);
        globalHistoryRadio.setText("Global History");
        globalHistoryRadio.setToolTipText("Undo/redo edits cross over from multiple panes. Warning: changing this option will erase your session's history.");
        settingsMenu.add(globalHistoryRadio);

        localHistoryRadio.setSelected(true);
        localHistoryRadio.setText("Local History");
        localHistoryRadio.setToolTipText("Undo/redo edits are constrained to the individual pane. Warning: changing this option will erase your session's history.");
        settingsMenu.add(localHistoryRadio);

        jMenuBar1.add(settingsMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileActionPerformed
        //Sarmad's feature
        //Adapted to split workspaces by Robertson
//        BufferedOutputStream out;
        String name="";
        f[0] = new File("");
        file = new File("");
        File file2 = new File("");

        if (saveAsDone == false){
            if (indVWS > 0) {
                int n = JOptionPane.showConfirmDialog(
                        jPanel1,
                        "Would you like to save all of your windows in the same place?",
                        "Saving All Windows to the Same Place",
                        JOptionPane.YES_NO_OPTION);

                if (n == 0) {
                    sameLocation = true;
                }
            }

            for (int i = 0; i <= indVWS; i++) {
                if (sameLocation == false||i==0) {
                    saveChooser.setMultiSelectionEnabled(false);

                    saveChooser.setDialogTitle("Save - Window " + i);

                    int option = saveChooser.showSaveDialog(ScribPadGui.this);

                    if (option == JFileChooser.APPROVE_OPTION) {

                        StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                        HTMLEditorKit kit = new HTMLEditorKit();

                        try {
                            oldOut = new BufferedOutputStream(new FileOutputStream(saveChooser.getSelectedFile().getAbsoluteFile()));

                            kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());

                            baseName = saveChooser.getSelectedFile().getName();

                            f[i] = new File(saveChooser.getSelectedFile().getName());
                            file = saveChooser.getSelectedFile();

                        } catch (FileNotFoundException e) {

                        } catch (IOException e) {

                        } catch (BadLocationException e) {

                        }
                    }
                    numSavedSpaces++;
                    splitsSaved = true;
                }

                if (sameLocation == true&&i!=0) {
                    saveChooser = new JFileChooser();

                    saveChooser.setMultiSelectionEnabled(false);

                    saveChooser.setDialogTitle("Save - Window " + i);

                    saveChooser.setSelectedFile(file);
                    baseName = saveChooser.getSelectedFile().toString();
                    name = baseName + i;
                    saveChooser.setSelectedFile(file2=new File(name));

                    int option = JFileChooser.APPROVE_OPTION;

                    if (option == JFileChooser.APPROVE_OPTION) {

                        StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                        HTMLEditorKit kit = new HTMLEditorKit();

                        try {
                            oldOut = new BufferedOutputStream(new FileOutputStream(saveChooser.getSelectedFile().getAbsoluteFile()));
                            kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());
                        } catch (FileNotFoundException e) {

                        } catch (IOException e) {

                        } catch (BadLocationException e) {

                        }
                    }
                    saveChooser.setSelectedFile(file);
                    numSavedSpaces++;
                    splitsSaved = true;
                }
            }
            saveAsDone = true;
        } else {
            if (splitsSaved == false) {
                if (indVWS > 0) {
                    int n = JOptionPane.showConfirmDialog(
                            jPanel1,
                            "Would you like to save all of your windows in the same place?",
                            "Saving All Windows to the Same Place",
                            JOptionPane.YES_NO_OPTION);

                    if (n == 0) {
                        sameLocation = true;
                    }
                }
            }
            for (int i = 0; i <= indVWS; i++){
                if (i==0) {
                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();
                    
                    try {
                        file.delete();
                        f[i].delete();
                        oldOut = new BufferedOutputStream(new FileOutputStream(saveChooser.getSelectedFile().getAbsoluteFile()));
                        kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());
                        baseName = saveChooser.getSelectedFile().getName();
                        file = saveChooser.getSelectedFile();
                        f[i] = new File(saveChooser.getSelectedFile().getName());
                    } catch (FileNotFoundException e){

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                    splitsSaved = true;
                }
                // This doesn't work yet
                if (sameLocation == false && i > 0){
                    StyledDocument firstDoc = (StyledDocument) textArrV[0].getDocument();
                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();
                    HTMLEditorKit kit = new HTMLEditorKit();
//                    System.out.println(saveChooser.getSelectedFile().getName());
                    saveChooser.setSelectedFile(f[i]);
                    try {
//                        System.out.println(saveChooser.getSelectedFile().getName());
                        f[0].delete();
                        f[i].delete();
//                        System.out.println(saveChooser.getSelectedFile().getName());
                        oldOut = new BufferedOutputStream(new FileOutputStream(saveChooser.getSelectedFile().getAbsoluteFile()));
                        kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());
                        f[i] = saveChooser.getSelectedFile();

                        kit.write(oldOut, firstDoc, firstDoc.getStartPosition().getOffset(), doc.getLength());
                        f[0] = saveChooser.getSelectedFile();
//                        System.out.println(saveChooser.getSelectedFile().getName());
                    } catch (FileNotFoundException e) {

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                    saveChooser.setSelectedFile(f[i]);
                    splitsSaved = true;
                }
                if ((sameLocation == false) && ((indVWS + 1) != numSavedSpaces)){
                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();
                    saveChooser.setMultiSelectionEnabled(false);

                    saveChooser.setDialogTitle("Save - Window " + i);
                    
                    int option = saveChooser.showSaveDialog(ScribPadGui.this);

                    if (option == JFileChooser.APPROVE_OPTION) {

                        try {
                            f[i].delete();
                            oldOut = new BufferedOutputStream(new FileOutputStream(saveChooser.getSelectedFile().getAbsoluteFile()));

                            kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());

                            baseName = saveChooser.getSelectedFile().getName();

                            f[i] = saveChooser.getSelectedFile();

                        } catch (FileNotFoundException e) {

                        } catch (IOException e) {

                        } catch (BadLocationException e) {

                        }
                    }
                    numSavedSpaces++;
                    splitsSaved = true;
                }
                if (sameLocation == true&&i!=0) {
                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();
                    saveChooser.setSelectedFile(file);
                    baseName = saveChooser.getSelectedFile().toString();
                    name = baseName + i;
                    saveChooser.setSelectedFile(file2=new File(name));
                    try {
                        file2.delete();
                        oldOut = new BufferedOutputStream(new FileOutputStream(saveChooser.getSelectedFile().getAbsoluteFile()));

                        kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());

                    } catch (FileNotFoundException e) {

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                    saveChooser.setSelectedFile(file);
                    splitsSaved = true;
                }
            }
        }
//        System.out.println(indVWS + 1);
//        System.out.println(numSavedSpaces);
        saved = true;
    }//GEN-LAST:event_saveFileActionPerformed

    private void saveFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileQuickButtonActionPerformed
        //Sarmad's feature
        //Adapted to split workspaces by Robertson
        boolean sameLocation = false;
        BufferedOutputStream out, oldOut=null;
        File f = null;
        String name="";
        
        if (indVWS > 0) {
            int n = JOptionPane.showConfirmDialog(
                    jPanel1,
                    "Would you like to save all of your windows in the same place?",
                    "Saving All Windows to the Same Place",
                    JOptionPane.YES_NO_OPTION);

            if (n == 0) {
                sameLocation = true;
            }
        }
        
        for (int i = 0; i <= indVWS; i++) {
            if (sameLocation == false||i==0) {
                JFileChooser chooser = new JFileChooser();

                chooser.setMultiSelectionEnabled(false);

                chooser.setDialogTitle("Save - Window " + i);

                int option = chooser.showSaveDialog(ScribPadGui.this);

                if (option == JFileChooser.APPROVE_OPTION) {

                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();
                   
                    try {
                        oldOut = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                        kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());
                        
                        name = chooser.getSelectedFile().getName();
                        
                        f = chooser.getSelectedFile();
                        
                    } catch (FileNotFoundException e) {

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                }
            }

            if (sameLocation == true&&i!=0) {
                JFileChooser chooser = new JFileChooser();

                chooser.setMultiSelectionEnabled(false);
                
                chooser.setDialogTitle("Save - Window " + i);
               
                chooser.setSelectedFile(f);
                name = chooser.getSelectedFile().toString().concat(""+1);
                chooser.setSelectedFile(f=new File(name));
               
                int option = JFileChooser.APPROVE_OPTION;

                if (option == JFileChooser.APPROVE_OPTION) {

                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();

                    try {
                        out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                        kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

                    } catch (FileNotFoundException e) {

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                }
            }

        }
        saved = true;
    }//GEN-LAST:event_saveFileQuickButtonActionPerformed

    private void cutTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextQuickButtonActionPerformed
        //Logan's feature
        getFocusedComponent().cut();
    }//GEN-LAST:event_cutTextQuickButtonActionPerformed

    private void changeColorQuickBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeColorQuickBtnActionPerformed
        //Sarmad's feature
        int start = getFocusedComponent().getSelectionStart();
        int end = getFocusedComponent().getSelectionEnd();
        int selectedLength = end-start;
        StyledDocument style = getFocusedComponent().getStyledDocument();
        AttributeSet oldset = style.getCharacterElement(end-1).getAttributes();
        StyleContext sc = StyleContext.getDefaultStyleContext();
        fontColor = JColorChooser.showDialog(this, "Select Text Color", clrCrnt);
        AttributeSet s = sc.addAttribute(oldset, StyleConstants.Foreground, fontColor);
        style.setCharacterAttributes(start, selectedLength, s, true);
    }//GEN-LAST:event_changeColorQuickBtnActionPerformed

    private void fontDesignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontDesignActionPerformed
        //Sarmad's feature
        fontDesign.setFocusable(false);
        String style = new String(fontDesign.getSelectedItem().toString());
        Action action = new StyledEditorKit.FontFamilyAction("Font size", style);
        action.actionPerformed(null);
    }//GEN-LAST:event_fontDesignActionPerformed

    private void fontSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontSizeActionPerformed
        //Sarmad's feature
        fontSize.setFocusable(false);
        value = Integer.parseInt(fontSize.getSelectedItem().toString());
        Action action = new StyledEditorKit.FontSizeAction("Font size", value);
        action.actionPerformed(null);
    }//GEN-LAST:event_fontSizeActionPerformed

    private void newFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileQuickButtonActionPerformed
        //Sarmad's feature
        getFocusedComponent().setText("");
        setTitle(fileName);
        saved = false;
        saveAsDone = false;
    }//GEN-LAST:event_newFileQuickButtonActionPerformed

    private void newFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileActionPerformed
        //Sarmad's feature
        getFocusedComponent().setText("");
        setTitle(fileName);
        saved = false;
        saveAsDone = false;
    }//GEN-LAST:event_newFileActionPerformed

    private void copyTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextQuickButtonActionPerformed
        //Logan's feature
        getFocusedComponent().copy();
    }//GEN-LAST:event_copyTextQuickButtonActionPerformed

    private void pasteTextQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextQuickButtonActionPerformed
        //Logan's feature
        getFocusedComponent().paste();
    }//GEN-LAST:event_pasteTextQuickButtonActionPerformed

    private void cutTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextActionPerformed
        //Logan's feature
        getFocusedComponent().cut();
    }//GEN-LAST:event_cutTextActionPerformed

    private void copyTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextActionPerformed
        //Logan's feature
        getFocusedComponent().copy();
    }//GEN-LAST:event_copyTextActionPerformed

    private void pasteTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextActionPerformed
        //Logan's feature
        getFocusedComponent().paste();
    }//GEN-LAST:event_pasteTextActionPerformed

    private void wordCounterMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wordCounterMenuItemActionPerformed
        //Xi's feature
        String text = getFocusedComponent().getText();
        JOptionPane.showMessageDialog(this,"Total words: "+ new StringTokenizer(text).countTokens()); 
    }//GEN-LAST:event_wordCounterMenuItemActionPerformed

    private void undoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoMenuItemActionPerformed
        //Logan's feature
        if (localHistoryRadio.isSelected()){
            undoManager[getActiveIndex()].undo();
        } else {
            undoManagerGlobal.undo();
        }
    }//GEN-LAST:event_undoMenuItemActionPerformed

    private void redoMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoMenuItemActionPerformed
        //Logan's feature
        if (localHistoryRadio.isSelected()){
            undoManager[getActiveIndex()].redo();
        } else {
            undoManagerGlobal.redo();
        }
    }//GEN-LAST:event_redoMenuItemActionPerformed

    private void openFileQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileQuickButtonActionPerformed
        //Sarmad's feature
        //Adapted to split workspaces by Julia
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(true);
        if (chooser.getSelectedFiles().length > 1){
            multiFilesChosen = true;
        }
        if (multiFilesChosen == true){
            
        }
        int option = chooser.showOpenDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            File file = chooser.getSelectedFile();

            jTextPane1.setEditorKit(new HTMLEditorKit());

            try {

            FileReader reader = new FileReader(file);

            jTextPane1.read(reader, file);

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            }
        }
    }//GEN-LAST:event_openFileQuickButtonActionPerformed

    private void openFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileActionPerformed
        //Sarmad's feature
        JFileChooser chooser = new JFileChooser();
            
        chooser.setMultiSelectionEnabled(false);

        int option = chooser.showOpenDialog(ScribPadGui.this);

        if (option == JFileChooser.APPROVE_OPTION) {

            File file = chooser.getSelectedFile();

            jTextPane1.setEditorKit(new HTMLEditorKit());

            try {

            FileReader reader = new FileReader(file);

            jTextPane1.read(reader, file);

            } catch (FileNotFoundException e) {

            } catch (IOException e){

            }
        }
    }//GEN-LAST:event_openFileActionPerformed

    private void saveAsFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveAsFileActionPerformed
        //Sarmad's feature
        //Debugged by Robertson
        boolean sameLocation = false;
        BufferedOutputStream out, oldOut=null;
        File f = null;
        String name="";
        
        if (indVWS > 0) {
            int n = JOptionPane.showConfirmDialog(
                    jPanel1,
                    "Would you like to save all of your windows in the same place?",
                    "Saving All Windows to the Same Place",
                    JOptionPane.YES_NO_OPTION);

            if (n == 0) {
                sameLocation = true;
            }
        }
        
        for (int i = 0; i <= indVWS; i++) {
            if (sameLocation == false||i==0) {
                JFileChooser chooser = new JFileChooser();

                chooser.setMultiSelectionEnabled(false);

                chooser.setDialogTitle("Save - Window " + i);

                int option = chooser.showSaveDialog(ScribPadGui.this);

                if (option == JFileChooser.APPROVE_OPTION) {

                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();
                   
                    try {
                        oldOut = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                        kit.write(oldOut, doc, doc.getStartPosition().getOffset(), doc.getLength());
                        
                        name = chooser.getSelectedFile().getName();
                        
                        f = chooser.getSelectedFile();
                        
                    } catch (FileNotFoundException e) {

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                }
            }

            if (sameLocation == true&&i!=0) {
                JFileChooser chooser = new JFileChooser();

                chooser.setMultiSelectionEnabled(false);
                
                chooser.setDialogTitle("Save - Window " + i);
               
                chooser.setSelectedFile(f);
                name = chooser.getSelectedFile().toString().concat(""+1);
                chooser.setSelectedFile(f=new File(name));
               
                int option = JFileChooser.APPROVE_OPTION;

                if (option == JFileChooser.APPROVE_OPTION) {

                    StyledDocument doc = (StyledDocument) textArrV[i].getDocument();

                    HTMLEditorKit kit = new HTMLEditorKit();

                    try {
                        out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));

                        kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());

                    } catch (FileNotFoundException e) {

                    } catch (IOException e) {

                    } catch (BadLocationException e) {

                    }
                }
            }

        }
        saved = true;
        saveAsDone = true;
    }//GEN-LAST:event_saveAsFileActionPerformed

    private void exitFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitFileActionPerformed
        // Julia's feature
        System.exit(0);
    }//GEN-LAST:event_exitFileActionPerformed

    private void searchButtonItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonItemActionPerformed
        // Xi's feature
        if(searchTextfield.getText().equals("")){        
        }
        else
        highlight(getFocusedComponent(), searchTextfield.getText());
    }//GEN-LAST:event_searchButtonItemActionPerformed

    private void insertImageMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertImageMenuItemActionPerformed
        // Julia's feature
        insertActionPerformed();
    }//GEN-LAST:event_insertImageMenuItemActionPerformed

    private void undoQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoQuickButtonActionPerformed
        // Logan's feature
        if (localHistoryRadio.isSelected()){
            undoManager[getActiveIndex()].undo();
        } else {
            undoManagerGlobal.undo();
        }
    }//GEN-LAST:event_undoQuickButtonActionPerformed

    private void redoQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoQuickButtonActionPerformed
        //Logan's feature
        if (localHistoryRadio.isSelected()){
            undoManager[getActiveIndex()].redo();
        } else {
            undoManagerGlobal.redo();
        }
    }//GEN-LAST:event_redoQuickButtonActionPerformed

    private void selectAllMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectAllMenuItemActionPerformed
        // Julia's feature
        getFocusedComponent().selectAll();
    }//GEN-LAST:event_selectAllMenuItemActionPerformed

    private void clearFormattingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearFormattingActionPerformed
        // Julia's feature
        int start = getFocusedComponent().getSelectionStart();
        int end = getFocusedComponent().getSelectionEnd();
        int selectedLength = end - start;
        if (selectedLength == 0){
            
        } else {
            Color backgroundClr = getFocusedComponent().getBackground();
            Font font = new Font("Tahoma", Font.PLAIN, 11);
            setJTextPaneFont(getFocusedComponent(), font, Color.black, backgroundClr, start);
        }
    }//GEN-LAST:event_clearFormattingActionPerformed

    private void clearSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearSearchActionPerformed
        // Julia's feature
        if (getFocusedComponent().getText() == null){
            
        } else {
            searchTextfield.setText("");
            removeHighlights(getFocusedComponent());
        }
    }//GEN-LAST:event_clearSearchActionPerformed

    private void clearSearchMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearSearchMouseEntered
        // Julia's feature
        clearSearch.setForeground(Color.WHITE);
        clearSearch.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_clearSearchMouseEntered

    private void clearSearchMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearSearchMouseExited
        // Julia's feature
        clearSearch.setForeground(Color.BLACK);
        clearSearch.setBackground(UIManager.getColor("control"));
    }//GEN-LAST:event_clearSearchMouseExited

    private void clearFormattingQuickActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearFormattingQuickActionPerformed
        // Julia's feature
        int start = getFocusedComponent().getSelectionStart();
        int end = getFocusedComponent().getSelectionEnd();
        int selectedLength = end - start;
        if (selectedLength == 0){
            
        } else {
            Color backgroundClr = getFocusedComponent().getBackground();
            Font font = new Font("Tahoma", Font.PLAIN, 11);
            setJTextPaneFont(getFocusedComponent(), font, Color.black, backgroundClr, start);
        }
    }//GEN-LAST:event_clearFormattingQuickActionPerformed

    private void btnAddVerticalWorkSpaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddVerticalWorkSpaceActionPerformed
        // Robertson's feature
        //NEW NEW NEW Robertson's SplitScreen Thing Vertical AND HORIZONTAL
        //Don't let the name of the button variable fool you
        //try typing in the canvas either /splitvert or /spithoriz and press the split button under tools
        //ORder Matters so try /spitvert/horiz or /splithoriz/splitvert
        //count a new vertical pane
        //indVWS means the index of the window being added 
    
        for (int p = 0; p <= indVWS; p++) {

            if (textArrV[p].getText().contains("/splitvert")
                    || textArrV[p].getText().contains("/splithoriz")) {
                //if /splithoriz comes first
                if (textArrV[p].getText().indexOf("/splitvert")
                        < textArrV[p].getText().indexOf("/splithoriz")) {

                    
                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splitvert")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);
                        
                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);
                        
                        //Size the old pane
                        int desiredLen = (scrollArrV[p].getSize().width) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width) / 2 - 1,
                                scrollArrV[p].getSize().height);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize(desiredLen,
                                scrollArrV[p].getSize().height);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX() + scrollArrV[p].getSize().width + 2,
                                scrollArrV[p].getY());
                        indVWS++;
                    }
                    
                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splithoriz")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);
                        
                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);
                        
                        //Size the old pane
                        int desiredHeight = (scrollArrV[p].getSize().height) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width),
                                (scrollArrV[p].getSize().height) / 2 - 1);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize((scrollArrV[p].getSize().width),
                                desiredHeight);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX(),
                                scrollArrV[p].getY() + scrollArrV[p].getSize().height + 2);
                        indVWS++;
                    }
                   
                } //if /splitvert comes first
                else if (textArrV[p].getText().indexOf("/splithoriz")
                        < textArrV[p].getText().indexOf("/splitvert")) {
                    //for (int i = 0; i <= indVWS; i++) {
                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splithoriz")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);
                        
                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);
                        
                        //Size the old pane
                        int desiredHeight = (scrollArrV[p].getSize().height) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width),
                                (scrollArrV[p].getSize().height) / 2 - 1);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize((scrollArrV[p].getSize().width),
                                desiredHeight);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX(),
                                scrollArrV[p].getY() + scrollArrV[p].getSize().height + 2);
                        indVWS++;
                    }
                  
                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splitvert")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);
                        
                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);
                        
                        //Size the old pane
                        int desiredLen = (scrollArrV[p].getSize().width) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width) / 2 - 1,
                                scrollArrV[p].getSize().height);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize(desiredLen,
                                scrollArrV[p].getSize().height);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX() + scrollArrV[p].getSize().width + 2,
                                scrollArrV[p].getY());
                        indVWS++;
                    }
                   
                    //just vert
                } else if (textArrV[p].getText().contains("/splitvert")) {
                    //make a new pane 
                    scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                    textArrV[indVWS + 1] = new javax.swing.JTextPane();
                    jPanel1.add(scrollArrV[indVWS + 1]);
                    scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);
                    
                    paneListeners(indVWS + 1);
                    undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                    undoRedoInitGlobal(textArrV[indVWS + 1]);
                    
                    //Size the old pane
                    int desiredLen = (scrollArrV[p].getSize().width) / 2 - 1;
                    scrollArrV[p].setSize((scrollArrV[p].getSize().width) / 2 - 1,
                            scrollArrV[p].getSize().height);
                    //Size the new pane and place it
                    scrollArrV[indVWS + 1].setSize(desiredLen,
                            scrollArrV[p].getSize().height);
                    scrollArrV[indVWS + 1].setLocation(
                            scrollArrV[p].getX() + scrollArrV[p].getSize().width + 2,
                            scrollArrV[p].getY());
                    indVWS++;
                    //just horiz
                } else if (textArrV[p].getText().contains("/splithoriz")) {
                    //make a new pane 
                    scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                    textArrV[indVWS + 1] = new javax.swing.JTextPane();
                    jPanel1.add(scrollArrV[indVWS + 1]);
                    scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);
                    
                    paneListeners(indVWS + 1);
                    undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                    undoRedoInitGlobal(textArrV[indVWS + 1]);
                    
                    //Size the old pane
                    int desiredHeight = (scrollArrV[p].getSize().height) / 2 - 1;
                    scrollArrV[p].setSize((scrollArrV[p].getSize().width),
                            (scrollArrV[p].getSize().height) / 2 - 1);
                    //Size the new pane and place it
                    scrollArrV[indVWS + 1].setSize((scrollArrV[p].getSize().width),
                            desiredHeight);
                    scrollArrV[indVWS + 1].setLocation(
                            scrollArrV[p].getX(),
                            scrollArrV[p].getY() + scrollArrV[p].getSize().height + 2);
                    indVWS++;
                }

            }
        }
        splitsSaved = false;
    }//GEN-LAST:event_btnAddVerticalWorkSpaceActionPerformed

    private void highlightQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_highlightQuickButtonActionPerformed
        // Xi's feature
        int start = getFocusedComponent().getSelectionStart();
        int end = getFocusedComponent().getSelectionEnd();
        int selectedLength =end-start;
        if (selectedLength == 0) {

        } else {
            StyledDocument style = getFocusedComponent().getStyledDocument();
            AttributeSet oldset =style.getCharacterElement(end-1).getAttributes();
            StyleContext sc = StyleContext.getDefaultStyleContext();
            AttributeSet s = sc.addAttribute(oldset, StyleConstants.Background, highlightColor );
            style.setCharacterAttributes(start, selectedLength, s, true);
        }
    }//GEN-LAST:event_highlightQuickButtonActionPerformed

    private void clearHighlightQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearHighlightQuickButtonActionPerformed
        // Xi's feature
        int start = getFocusedComponent().getSelectionStart();
        int end = getFocusedComponent().getSelectionEnd();
        int selectedLength = end - start;
        if (selectedLength == 0) {
            
        } else {
            StyledDocument style = getFocusedComponent().getStyledDocument();
            AttributeSet oldest = style.getCharacterElement(end-1).getAttributes();
            StyleContext sc = StyleContext.getDefaultStyleContext();
            Color backgroundClr = getFocusedComponent().getBackground();
            AttributeSet s =sc.addAttribute(oldest, StyleConstants.Background, backgroundClr);
            style.setCharacterAttributes(start, selectedLength, s, true);
        }
    }//GEN-LAST:event_clearHighlightQuickButtonActionPerformed

    private void fontHighlightColorMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontHighlightColorMenuItemActionPerformed
        // Xi's feature
        Color newColor =JColorChooser.showDialog(this,"Select Highlight Color", clrhighlit);        
        highlightColor = newColor;
    }//GEN-LAST:event_fontHighlightColorMenuItemActionPerformed

    private void printFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printFileActionPerformed
        // Xi and Julia's feature
        try {
           Boolean complete= jTextPane1.print(header, footer);
           if(complete){
                //JOptionPane.showMessageDialog(null, "Done printing","Information",JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null,"Job cancelled","Error",JOptionPane.ERROR_MESSAGE);
            } 
        } catch (PrinterException ex) {
            Logger.getLogger(ScribPadGui.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_printFileActionPerformed

    private void headerAndFooterMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_headerAndFooterMenuItemActionPerformed
       //Xi and Julia's feature
       HeaderFooterFrame.setVisible(true);
    }//GEN-LAST:event_headerAndFooterMenuItemActionPerformed

    private void headFootOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_headFootOKActionPerformed
       //Xi and Julia's feature
       header = new MessageFormat(headerjTextPane.getText());
       footer = new MessageFormat(footerjTextPane.getText());
       HeaderFooterFrame.dispatchEvent(new WindowEvent(HeaderFooterFrame, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_headFootOKActionPerformed

    private void headFootCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_headFootCancelActionPerformed
       //Xi and Julia's feature
       HeaderFooterFrame.dispatchEvent(new WindowEvent(HeaderFooterFrame, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_headFootCancelActionPerformed

    private void incSizeMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incSizeMenuItemActionPerformed
        // Julia's feature
        MutableAttributeSet attrs=((StyledEditorKit)getFocusedComponent().getEditorKit()).getInputAttributes();
        value = StyleConstants.getFontSize(attrs);
        value++;
        Action action = new StyledEditorKit.FontSizeAction("Font size", value);
        action.actionPerformed(null);
    }//GEN-LAST:event_incSizeMenuItemActionPerformed

    private void decSizeMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_decSizeMenuItemActionPerformed
        // Julia's feature
        MutableAttributeSet attrs=((StyledEditorKit)getFocusedComponent().getEditorKit()).getInputAttributes();
        value = StyleConstants.getFontSize(attrs);
        value--;
        Action action = new StyledEditorKit.FontSizeAction("Font size", value);
        action.actionPerformed(null);
    }//GEN-LAST:event_decSizeMenuItemActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // Julia's feature
        if (saved == false){
            Object[] choices = {"Save and exit", "Exit without saving", "Cancel"};
            Object defaultChoice = choices[0];
            int choice = JOptionPane.showOptionDialog(this,"Warning: there are unsaved changes",
                "Unsaved changes",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE,
                null,
                choices,
                defaultChoice);
            switch (choice){
                case JOptionPane.YES_OPTION:
                    if (saveAsDone == false){
                        JFileChooser chooser = new JFileChooser();
                        chooser.setMultiSelectionEnabled(false);
                        int option = chooser.showSaveDialog(ScribPadGui.this);

                        if (option == JFileChooser.APPROVE_OPTION) {
                            StyledDocument doc = (StyledDocument)jTextPane1.getDocument();
                            HTMLEditorKit kit = new HTMLEditorKit();
                            BufferedOutputStream out;
                            try {
                                out = new BufferedOutputStream(new FileOutputStream(chooser.getSelectedFile().getAbsoluteFile()));
                                kit.write(out, doc, doc.getStartPosition().getOffset(), doc.getLength());
                            } catch (FileNotFoundException e) {
                            } catch (IOException e){
                            } catch (BadLocationException e){
                            }
                        }
                        saved = true;
                        saveAsDone = true;
                    } else{
                        // TODO if user already has a save file
                    }
                    break;
                case JOptionPane.NO_OPTION:
                    this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                    break;
                case JOptionPane.CANCEL_OPTION:
                    this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
                    break;
            }
        }
    }//GEN-LAST:event_formWindowClosing

    private void loremIpsumMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loremIpsumMenuItemActionPerformed
        // Julia's feature
        String loremIpsum = readFileAsString();
        append(loremIpsum);
    }//GEN-LAST:event_loremIpsumMenuItemActionPerformed

    private void LineSpacerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LineSpacerActionPerformed
        // Robertson's feature
        LineSpacer.setFocusable(false);
        Float value = Float.parseFloat(LineSpacer.getSelectedItem().toString());
        
        SimpleAttributeSet aSet = new SimpleAttributeSet();
        StyleConstants.setLineSpacing(aSet, (float)((value-1)));
       
        getFocusedComponent().setParagraphAttributes(aSet, false);
    }//GEN-LAST:event_LineSpacerActionPerformed

    private void hyperlinkQuickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hyperlinkQuickButtonActionPerformed
         // Xi's feature
        int start = getFocusedComponent().getSelectionStart();
        int end = getFocusedComponent().getSelectionEnd();
        int selectedLength =end-start;
        if (selectedLength == 0) {

        } else {
            StyledDocument style = getFocusedComponent().getStyledDocument();
            AttributeSet oldset =style.getCharacterElement(end-1).getAttributes();
            StyleContext sc = StyleContext.getDefaultStyleContext();
            AttributeSet s = sc.addAttribute(oldset, StyleConstants.Background, highlightColor );
            style.setCharacterAttributes(start, selectedLength, s, true);
        }
        //hyperlink
        /*
        Desktop browser = Desktop.getDesktop();
        try{ browser.browse(new URI("http://www.google.com"));
        }
        catch(IOException err){
        }
        catch(URSSyntaxException err){
        }
        */
        
            
     }
        
        
        
        //hyperlink
        
        
        
    }                            
    }//GEN-LAST:event_hyperlinkQuickButtonActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ScribPadGui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScribPadGui().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFrame HeaderFooterFrame;
    private javax.swing.JComboBox<String> LineSpacer;
    private javax.swing.JMenu alignAndIndentMenu;
    private javax.swing.JButton boldQuickButton;
    private javax.swing.JMenuItem btnAddVerticalWorkSpace;
    private javax.swing.JMenu capitalizationMenu;
    private javax.swing.JMenuItem centerAlignMenuItem;
    private javax.swing.JButton changeColorQuickBtn;
    private javax.swing.JMenuItem clearFormatting;
    private javax.swing.JButton clearFormattingQuick;
    private javax.swing.JButton clearHighlightQuickButton;
    private javax.swing.JButton clearSearch;
    private javax.swing.JMenuItem copyText;
    private javax.swing.JButton copyTextQuickButton;
    private javax.swing.JMenuItem cutText;
    private javax.swing.JButton cutTextQuickButton;
    private javax.swing.JMenuItem decSizeMenuItem;
    private javax.swing.JCheckBoxMenuItem disPaneBorder;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitFile;
    private javax.swing.JMenu fileMenu;
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler3;
    private javax.swing.Box.Filler filler5;
    private javax.swing.Box.Filler filler6;
    private javax.swing.Box.Filler filler7;
    private javax.swing.Box.Filler filler8;
    private javax.swing.Box.Filler filler9;
    private javax.swing.JMenuItem fontBoldMenuItem;
    private javax.swing.JComboBox<String> fontDesign;
    private javax.swing.JMenu fontEditMenu;
    private javax.swing.JMenuItem fontHighlightColorMenuItem;
    private javax.swing.JMenuItem fontItalicMenuItem;
    private javax.swing.JComboBox<String> fontSize;
    private javax.swing.JMenuItem fontStrikethroughMenuItem;
    private javax.swing.JMenuItem fontUnderlineMenuItem;
    private javax.swing.JLabel footerLabel;
    private javax.swing.JTextPane footerjTextPane;
    private javax.swing.JButton formatCenter;
    private javax.swing.JButton formatLeft;
    private javax.swing.JMenu formatMenu;
    private javax.swing.JButton formatRight;
    private javax.swing.JRadioButtonMenuItem globalHistoryRadio;
    private javax.swing.JButton headFootCancel;
    private javax.swing.JButton headFootOK;
    private javax.swing.JMenuItem headerAndFooterMenuItem;
    private javax.swing.JLabel headerLabel;
    private javax.swing.JTextPane headerjTextPane;
    private javax.swing.JButton highlightQuickButton;
    private javax.swing.JButton hyperlinkQuickButton;
    private javax.swing.JMenuItem incSizeMenuItem;
    private javax.swing.JMenuItem insertImageMenuItem;
    private javax.swing.JMenu insertMenu;
    private javax.swing.JButton italicQuickButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JToolBar.Separator jSeparator4;
    private javax.swing.JToolBar.Separator jSeparator5;
    private javax.swing.JToolBar.Separator jSeparator6;
    private javax.swing.JToolBar.Separator jSeparator7;
    private javax.swing.JPopupMenu.Separator jSeparator8;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JMenuItem leftAlignMenuItem;
    private javax.swing.JRadioButtonMenuItem localHistoryRadio;
    private javax.swing.JMenuItem loremIpsumMenuItem;
    private javax.swing.JMenuItem lowercaseMenuItem;
    private javax.swing.JMenuItem newFile;
    private javax.swing.JButton newFileQuickButton;
    private javax.swing.JMenuItem openFile;
    private javax.swing.JButton openFileQuickButton;
    private javax.swing.JMenuItem pasteText;
    private javax.swing.JButton pasteTextQuickButton;
    private javax.swing.JCheckBoxMenuItem persistentBold;
    private javax.swing.JCheckBoxMenuItem persistentClear;
    private javax.swing.JCheckBoxMenuItem persistentFontColor;
    private javax.swing.JCheckBoxMenuItem persistentFontFamily;
    private javax.swing.JCheckBoxMenuItem persistentFontSize;
    private javax.swing.JCheckBoxMenuItem persistentHighlight;
    private javax.swing.JCheckBoxMenuItem persistentItalic;
    private javax.swing.JCheckBoxMenuItem persistentLowercase;
    private javax.swing.JMenu persistentOptions;
    private javax.swing.JCheckBoxMenuItem persistentStrikethrough;
    private javax.swing.JMenu persistentTextMenu;
    private javax.swing.JCheckBoxMenuItem persistentUnderline;
    private javax.swing.JCheckBoxMenuItem persistentUppercase;
    private javax.swing.JMenuItem printFile;
    private javax.swing.JToolBar quickToolBar;
    private javax.swing.JMenuItem redoMenuItem;
    private javax.swing.JButton redoQuickButton;
    private javax.swing.JMenuItem rightAlignMenuItem;
    private javax.swing.JMenuItem saveAsFile;
    private javax.swing.JMenuItem saveFile;
    private javax.swing.JButton saveFileQuickButton;
    private javax.swing.JButton searchButtonItem;
    private javax.swing.JTextField searchTextfield;
    private javax.swing.JMenuItem selectAllMenuItem;
    private javax.swing.JMenu settingsMenu;
    private javax.swing.JButton strikethroughQuickButton;
    private javax.swing.JMenu toolMenu;
    private javax.swing.JButton underlineQuickButton;
    private javax.swing.JMenuItem undoMenuItem;
    private javax.swing.JButton undoQuickButton;
    private javax.swing.JMenuItem uppercaseMenuItem;
    private javax.swing.JMenuItem wordCounterMenuItem;
    // End of variables declaration//GEN-END:variables
    // java undo and redo action classes

    // Logan's classes 
    class UndoHandler implements UndoableEditListener
    {

    /**
    * Messaged when the Document has created an edit, the edit is added to
    * <code>undoManager</code>, an instance of UndoManager.
    */
        @Override
        public void undoableEditHappened(UndoableEditEvent e)
        {
            undoManager[getActiveIndex()].addEdit(e.getEdit());
            undoAction[getActiveIndex()].update();
            redoAction[getActiveIndex()].update();
        }
    }

    class UndoAction extends AbstractAction
    {
        public UndoAction()
        {
            super("Undo");
            setEnabled(false);
        }

        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                undoManager[getActiveIndex()].undo();
            }
            catch (CannotUndoException ex)
            {
                // TODO deal with this
                //ex.printStackTrace();
            }
            
            update();
            redoAction[getActiveIndex()].update();
    }

    protected void update()
    {
        if (undoManager[getActiveIndex()].canUndo())
        {
            setEnabled(true);
            putValue(Action.NAME, undoManager[getActiveIndex()].getUndoPresentationName());
        }
        else
        {
            setEnabled(false);
            putValue(Action.NAME, "Undo");
        }
    }
}

    class RedoAction extends AbstractAction
    {
          public RedoAction()
          {
            super("Redo");
            setEnabled(false);
          }

          @Override
          public void actionPerformed(ActionEvent e)
          {
            try
            {
              undoManager[getActiveIndex()].redo();
            }
            catch (CannotRedoException ex)
            {

            }
            update();
            undoAction[getActiveIndex()].update();
          }

          protected void update()
          {
            if (undoManager[getActiveIndex()].canRedo())
            {
              putValue(Action.NAME, undoManager[getActiveIndex()].getRedoPresentationName());
              setEnabled(true);
            }
            else
            {
              setEnabled(false);
              putValue(Action.NAME, "Redo");
            }
          }
    }
    class UndoHandlerGlobal implements UndoableEditListener
    {

    /**
    * Messaged when the Document has created an edit, the edit is added to
    * <code>undoManager</code>, an instance of UndoManager.
    */
        @Override
        public void undoableEditHappened(UndoableEditEvent e)
        {
            undoManagerGlobal.addEdit(e.getEdit());
            undoActionGlobal.update();
            redoActionGlobal.update();
        }
    }

    class UndoActionGlobal extends AbstractAction
    {
        public UndoActionGlobal()
        {
            super("Undo");
            setEnabled(false);
        }

        @Override
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                undoManagerGlobal.undo();
            }
            catch (CannotUndoException ex)
            {
                // TODO deal with this
                //ex.printStackTrace();
            }
            
            update();
            redoActionGlobal.update();
    }

    protected void update()
    {
        if (undoManagerGlobal.canUndo())
        {
            setEnabled(true);
            putValue(Action.NAME, undoManager[getActiveIndex()].getUndoPresentationName());
        }
        else
        {
            setEnabled(false);
            putValue(Action.NAME, "Undo");
        }
    }
}

    class RedoActionGlobal extends AbstractAction
    {
          public RedoActionGlobal()
          {
            super("Redo");
            setEnabled(false);
          }

          @Override
          public void actionPerformed(ActionEvent e)
          {
            try
            {
              undoManagerGlobal.redo();
            }
            catch (CannotRedoException ex)
            {

            }
            update();
            undoActionGlobal.update();
          }

          protected void update()
          {
            if (undoManagerGlobal.canRedo())
            {
              putValue(Action.NAME, undoManagerGlobal.getRedoPresentationName());
              setEnabled(true);
            }
            else
            {
              setEnabled(false);
              putValue(Action.NAME, "Redo");
            }
          }
    }
    // End of Logan's classes
    // Start of insert images (Julia)
    private void insertActionPerformed()
    {
        JFileChooser jf=new JFileChooser();
        
        // Show open dialog
        int option=jf.showOpenDialog(this);
        
            // If user chooses to insert..
            if(option==JFileChooser.APPROVE_OPTION)
            {
                File file=jf.getSelectedFile();
                    if(isImage(file))
                    {
                        getFocusedComponent().insertIcon(new ImageIcon(file.getAbsolutePath()));
                    }
                    else
                    // Show an error message, if not an image
                    JOptionPane.showMessageDialog(this,"The file is not an image.","Not Image",JOptionPane.ERROR_MESSAGE);
            }
    }
    
    private boolean isImage(File file)
    {
        String name=file.getName();
            return name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg") || name.endsWith(".gif");
    }
    // End of insert images (Julia)
    // Start of clear formatting (Julia)
    public void setJTextPaneFont(JTextPane jtp, Font font, Color c, Color bg, int start) {
        // Start with the current input attributes for the JTextPane. This
        // should ensure that we do not wipe out any existing attributes
        // (such as alignment or other paragraph attributes) currently
        // set on the text area.
        MutableAttributeSet attrs = jtp.getInputAttributes();

        // Set the font family, size, and style, based on properties of the Font object.
        StyleConstants.setFontFamily(attrs, font.getFamily());
        StyleConstants.setFontSize(attrs, font.getSize());
        StyleConstants.setItalic(attrs, false);
        StyleConstants.setBold(attrs, false);
        StyleConstants.setUnderline(attrs, false);
        StyleConstants.setStrikeThrough(attrs, false);
        // Set the font color
        StyleConstants.setForeground(attrs, c);
        StyleConstants.setBackground(attrs, bg);

        // Retrieve the pane's document object
        StyledDocument doc = jtp.getStyledDocument();

        // Replace the style for the entire document.
        doc.setCharacterAttributes(start, getFocusedComponent().getSelectedText().length(), attrs, true);
    }
    // End of clear formatting (Julia)
    // Start of get active pane (Julia)
    protected final JTextPane getFocusedComponent()
    {
        if (indVWS == 0){
            activePane = jTextPane1;
        }else{
            KeyboardFocusManager kfm = KeyboardFocusManager.getCurrentKeyboardFocusManager();
            Component focused = kfm.getPermanentFocusOwner();
            if (focused instanceof JTextPane){
                activePane = (JTextPane) focused;
            }
        }
        return activePane;
    }
    // End of get active pane (Julia)
    // Start of active pane border (Julia)
    public void mouseClicked(MouseEvent e){
        if (disPaneBorder.isSelected()) {
            for (int i = 0; i < (indVWS + 1); i++) {
                textArrV[i].setBorder(BorderFactory.createEmptyBorder());
            }
        } else {   
            if (indVWS == 0) {

            } else {
                if ( SwingUtilities.isLeftMouseButton(e)  && e.getClickCount() == 1){
                    for (int i = 0; i < (indVWS + 1); i++) {
                        textArrV[i].setBorder(BorderFactory.createEmptyBorder());
                    }
                    getFocusedComponent().setBorder(BorderFactory.createLineBorder(Color.RED));
                }
            }
        }
    }
    public void mousePressed(MouseEvent e) {
    }
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    // End of active pane border (Julia)
    // Start of persistent font attributes (Julia)
    public void paneListeners(int num){
        textArrV[num].addMouseListener(this);
        textArrV[num].addCaretListener(new CaretListener(){
            public void caretUpdate(CaretEvent evt){
                int start = getFocusedComponent().getSelectionStart();
                int end = getFocusedComponent().getSelectionEnd();
                int selectedLength = end-start;
                
                if (persistentClear.isSelected()){
                    if (selectedLength == 0){
            
                    } else {
                        Color backgroundClr = getFocusedComponent().getBackground();
                        Font font = new Font("Tahoma", Font.PLAIN, 11);
                        setJTextPaneFont(getFocusedComponent(), font, Color.black, backgroundClr, start);
                    }
                }else{
                    if (persistentFontFamily.isSelected()){
                        String family = new String(fontDesign.getSelectedItem().toString());
                        Action action = new StyledEditorKit.FontFamilyAction("Font size", family);
                        action.actionPerformed(null);
                    }
                    if (persistentFontSize.isSelected()){
                        value = Integer.parseInt(fontSize.getSelectedItem().toString());
                        Action action = new StyledEditorKit.FontSizeAction("Font size", value);
                        action.actionPerformed(null);
                    }
                    if (persistentFontColor.isSelected()){
                        StyledDocument style = getFocusedComponent().getStyledDocument();
                        AttributeSet oldset = style.getCharacterElement(end-1).getAttributes();
                        StyleContext sc = StyleContext.getDefaultStyleContext();
                        AttributeSet s = sc.addAttribute(oldset, StyleConstants.Foreground, fontColor);
                        style.setCharacterAttributes(start, selectedLength, s, true);
                    }
                    if (persistentHighlight.isSelected()){
                        if (selectedLength == 0) {
                        } else {
                            StyledDocument style = getFocusedComponent().getStyledDocument();
                            AttributeSet oldset = style.getCharacterElement(end-1).getAttributes();
                            StyleContext sc = StyleContext.getDefaultStyleContext();
                            AttributeSet s = sc.addAttribute(oldset, StyleConstants.Background, highlightColor );
                            style.setCharacterAttributes(start, selectedLength, s, true);
                        }                    
                    }
                    if (persistentBold.isSelected()){
                        if (selectedLength == 0) {
                        } else {
                            StyledDocument style = getFocusedComponent().getStyledDocument();
                            MutableAttributeSet attrs = getFocusedComponent().getInputAttributes();
                            if (persistentFontColor.isSelected()){
                                StyleConstants.setForeground(attrs, fontColor);
                            }
                            if (persistentHighlight.isSelected()){
                                StyleConstants.setBackground(attrs, highlightColor);
                            }
                            StyleConstants.setBold(attrs, true);
                            style.setCharacterAttributes(start, selectedLength, attrs, true);
                        }
                    }
                    if (persistentItalic.isSelected()) {
                        if (selectedLength == 0) {
                        } else {
                            StyledDocument style = getFocusedComponent().getStyledDocument();
                            MutableAttributeSet attrs = getFocusedComponent().getInputAttributes();
                            if (persistentFontColor.isSelected()){
                                StyleConstants.setForeground(attrs, fontColor);
                            }
                            if (persistentHighlight.isSelected()){
                                StyleConstants.setBackground(attrs, highlightColor);
                            }
                            StyleConstants.setItalic(attrs, true);
                            style.setCharacterAttributes(start, selectedLength, attrs, true);
                        }
                    }
                    if (persistentUnderline.isSelected()) {
                        if (selectedLength == 0) {
                        } else {
                            StyledDocument style = getFocusedComponent().getStyledDocument();
                            MutableAttributeSet attrs = getFocusedComponent().getInputAttributes();
                            if (persistentFontColor.isSelected()){
                                StyleConstants.setForeground(attrs, fontColor);
                            }
                            if (persistentHighlight.isSelected()){
                                StyleConstants.setBackground(attrs, highlightColor);
                            }
                            StyleConstants.setUnderline(attrs, true);
                            style.setCharacterAttributes(start, selectedLength, attrs, true);
                        }
                    }
                    if (persistentStrikethrough.isSelected()){
                        if (selectedLength == 0) {
                        } else {
                            StyledDocument style = getFocusedComponent().getStyledDocument();
                            MutableAttributeSet attrs = getFocusedComponent().getInputAttributes();
                            if (persistentFontColor.isSelected()){
                                StyleConstants.setForeground(attrs, fontColor);
                            }
                            if (persistentHighlight.isSelected()){
                                StyleConstants.setBackground(attrs, highlightColor);
                            }
                            StyleConstants.setStrikeThrough(attrs, true);
                            style.setCharacterAttributes(start, selectedLength, attrs, true);
                        }
                    }
                    if (persistentLowercase.isSelected() && persistentUppercase.isSelected()){

                    } else {
                        if (persistentLowercase.isSelected() && !persistentUppercase.isSelected()){
                            if (selectedLength == 0) {
                            } else {
                                StyledDocument style = getFocusedComponent().getStyledDocument();
                                MutableAttributeSet attrs = getFocusedComponent().getInputAttributes();
                                if (persistentFontColor.isSelected()){
                                    StyleConstants.setForeground(attrs, fontColor);
                                }
                                if (persistentHighlight.isSelected()){
                                    StyleConstants.setBackground(attrs, highlightColor);
                                }
                                String lowerText = getFocusedComponent().getSelectedText().toLowerCase();
                                getFocusedComponent().replaceSelection(lowerText);
                                style.setCharacterAttributes(start, selectedLength, attrs, true);
                            }
                        }
                        if (persistentUppercase.isSelected() && !persistentLowercase.isSelected()){
                            if (selectedLength == 0) {
                            } else {
                                StyledDocument style = getFocusedComponent().getStyledDocument();
                                MutableAttributeSet attrs = getFocusedComponent().getInputAttributes();
                                if (persistentFontColor.isSelected()){
                                    StyleConstants.setForeground(attrs, fontColor);
                                }
                                if (persistentHighlight.isSelected()){
                                    StyleConstants.setBackground(attrs, highlightColor);
                                }
                                String upperText = getFocusedComponent().getSelectedText().toUpperCase();
                                getFocusedComponent().replaceSelection(upperText);
                                style.setCharacterAttributes(start, selectedLength, attrs, true);
                            }
                        }
                    }
                }
            }
        });
        textArrV[num].getDocument().addDocumentListener(new MyDocumentListener());
        textArrV[num].getDocument().putProperty("name", "Text Area");
    }
    // End of persistent font attributes (Julia)
    // Undo/Redo (Logan)
    private void undoRedoInitLocal(JTextPane pane, int index){
        undoHandler[index] = new UndoHandler();
        undoManager[index] = new UndoManager();
        editDocument[index] = pane.getDocument();
        editDocument[index].addUndoableEditListener(undoHandler[index]);
        
//        KeyStroke undoKeystroke = KeyStroke.getKeyStroke(KeyEvent.VK_Z, Event.CTRL_MASK);
//        KeyStroke redoKeystroke = KeyStroke.getKeyStroke(KeyEvent.VK_Y, Event.CTRL_MASK);

        undoAction[index] = new UndoAction();
//        pane.getInputMap().put(undoKeystroke, "undoKeystroke");
//        pane.getActionMap().put("undoKeystroke", undoAction);

        redoAction[index] = new RedoAction();
//        pane.getInputMap().put(redoKeystroke, "redoKeystroke");
//        pane.getActionMap().put("redoKeystroke", redoAction);
    }
    private void undoRedoInitGlobal(JTextPane pane){
        editDocumentGlobal = pane.getDocument();
        editDocumentGlobal.addUndoableEditListener(undoHandlerGlobal);
        
        undoActionGlobal = new UndoActionGlobal();
        redoActionGlobal = new RedoActionGlobal();
    }
    // End of Undo/Redo (Logan)
    class MyDocumentListener implements DocumentListener {
        public void insertUpdate(DocumentEvent e) {
            saved = false;
        }
        public void removeUpdate(DocumentEvent e) {
            saved = false;
        }
        public void changedUpdate(DocumentEvent e) {
            //Plain text components don't fire these events.
        }
    }
    public int getActiveIndex(){
        int index = 0;
        for (int i = 0; i < (indVWS + 1); i++) {
            if (textArrV[i].toString().equals(getFocusedComponent().toString())){
                index = i;
                return index;
            }
        }
        return index;
    }
    // Start of Lorem Ipsum (Julia)
    public void append(String s) {
       try {
          Document doc = getFocusedComponent().getDocument();
          doc.insertString(doc.getLength(), s, null);
       } catch(BadLocationException exc) {
          exc.printStackTrace();
       }
    }
    public static String readFileAsString(){
        String text = "";
        try{
            text = new String(Files.readAllBytes(Paths.get("LoremIpsum.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return text;
    }
    // End of Lorem Ipsum (Julia)
    // Start of indentation (Logan)
    public void setIndentation()
    {
        TabStop[] tabs = new TabStop[4];
        tabs[0] = new TabStop(60, TabStop.ALIGN_RIGHT, TabStop.LEAD_NONE);
        tabs[1] = new TabStop(100, TabStop.ALIGN_LEFT, TabStop.LEAD_NONE);
        tabs[2] = new TabStop(200, TabStop.ALIGN_CENTER, TabStop.LEAD_NONE);
        tabs[3] = new TabStop(300, TabStop.ALIGN_DECIMAL, TabStop.LEAD_NONE);
        TabSet tabset = new TabSet(tabs);

        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY,
        StyleConstants.TabSet, tabset);
        jTextPane1.setParagraphAttributes(aset, false);
        jTextPane1.setText("\tright\tleft\tcenter\tdecimal\n" + "\t1\t1\t1\t1.0\n"
        + "\t200.002\t200.002\t200.002\t200.002\n"
        + "\t.33\t.33\t.33\t.33\n");

        JFrame frame = new JFrame("TabExample");
        frame.setContentPane(new JScrollPane(jTextPane1));
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(360, 120);
        frame.setVisible(true);
    }
    // End of indentation (Logan)
    // Start of split workspaces (Robertson)
    // Adapted by Julia
    // Not being used yet
    public void splitWorkspace() throws IOException {
        Map< String,Integer> hm = new HashMap< String,Integer>();
        FileOutputStream fileOut = new FileOutputStream(f[0]);
        ObjectOutputStream out = new ObjectOutputStream(fileOut);
        for (int p = 0; p <= indVWS; p++) {

            if (textArrV[p].getText().contains("/splitvert")
                    || textArrV[p].getText().contains("/splithoriz")) {
                //if /splithoriz comes first
                if (textArrV[p].getText().indexOf("/splitvert")
                        < textArrV[p].getText().indexOf("/splithoriz")) {


                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splitvert")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);

                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);

                        //Size the old pane
                        int desiredLen = (scrollArrV[p].getSize().width) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width) / 2 - 1,
                                scrollArrV[p].getSize().height);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize(desiredLen,
                                scrollArrV[p].getSize().height);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX() + scrollArrV[p].getSize().width + 2,
                                scrollArrV[p].getY());
                        indVWS++;
                        hm.put(textArrV[p].getText(), indVWS);
                    }

                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splithoriz")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);

                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);

                        //Size the old pane
                        int desiredHeight = (scrollArrV[p].getSize().height) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width),
                                (scrollArrV[p].getSize().height) / 2 - 1);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize((scrollArrV[p].getSize().width),
                                desiredHeight);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX(),
                                scrollArrV[p].getY() + scrollArrV[p].getSize().height + 2);
                        indVWS++;
                        hm.put(textArrV[p].getText(), indVWS);
                    }

                } //if /splitvert comes first
                else if (textArrV[p].getText().indexOf("/splithoriz")
                        < textArrV[p].getText().indexOf("/splitvert")) {
                    //for (int i = 0; i <= indVWS; i++) {
                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splithoriz")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);

                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);

                        //Size the old pane
                        int desiredHeight = (scrollArrV[p].getSize().height) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width),
                                (scrollArrV[p].getSize().height) / 2 - 1);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize((scrollArrV[p].getSize().width),
                                desiredHeight);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX(),
                                scrollArrV[p].getY() + scrollArrV[p].getSize().height + 2);
                        indVWS++;
                        hm.put(textArrV[p].getText(), indVWS);
                    }

                    //if that pane says {vertsplit}
                    if (textArrV[p].getText().contains("/splitvert")) {
                        //make a new pane 
                        scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                        textArrV[indVWS + 1] = new javax.swing.JTextPane();
                        jPanel1.add(scrollArrV[indVWS + 1]);
                        scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);

                        paneListeners(indVWS + 1);
                        undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                        undoRedoInitGlobal(textArrV[indVWS + 1]);

                        //Size the old pane
                        int desiredLen = (scrollArrV[p].getSize().width) / 2 - 1;
                        scrollArrV[p].setSize((scrollArrV[p].getSize().width) / 2 - 1,
                                scrollArrV[p].getSize().height);
                        //Size the new pane and place it
                        scrollArrV[indVWS + 1].setSize(desiredLen,
                                scrollArrV[p].getSize().height);
                        scrollArrV[indVWS + 1].setLocation(
                                scrollArrV[p].getX() + scrollArrV[p].getSize().width + 2,
                                scrollArrV[p].getY());
                        indVWS++;
                        hm.put(textArrV[p].getText(), indVWS);
                    }

                    //just vert
                } else if (textArrV[p].getText().contains("/splitvert")) {
                    //make a new pane 
                    scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                    textArrV[indVWS + 1] = new javax.swing.JTextPane();
                    jPanel1.add(scrollArrV[indVWS + 1]);
                    scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);

                    paneListeners(indVWS + 1);
                    undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                    undoRedoInitGlobal(textArrV[indVWS + 1]);

                    //Size the old pane
                    int desiredLen = (scrollArrV[p].getSize().width) / 2 - 1;
                    scrollArrV[p].setSize((scrollArrV[p].getSize().width) / 2 - 1,
                            scrollArrV[p].getSize().height);
                    //Size the new pane and place it
                    scrollArrV[indVWS + 1].setSize(desiredLen,
                            scrollArrV[p].getSize().height);
                    scrollArrV[indVWS + 1].setLocation(
                            scrollArrV[p].getX() + scrollArrV[p].getSize().width + 2,
                            scrollArrV[p].getY());
                    indVWS++;
                    hm.put(textArrV[p].getText(), indVWS);
                    //just horiz
                } else if (textArrV[p].getText().contains("/splithoriz")) {
                    //make a new pane 
                    scrollArrV[indVWS + 1] = new javax.swing.JScrollPane();
                    textArrV[indVWS + 1] = new javax.swing.JTextPane();
                    jPanel1.add(scrollArrV[indVWS + 1]);
                    scrollArrV[indVWS + 1].setViewportView(textArrV[indVWS + 1]);

                    paneListeners(indVWS + 1);
                    undoRedoInitLocal(textArrV[indVWS + 1], indVWS + 1);
                    undoRedoInitGlobal(textArrV[indVWS + 1]);

                    //Size the old pane
                    int desiredHeight = (scrollArrV[p].getSize().height) / 2 - 1;
                    scrollArrV[p].setSize((scrollArrV[p].getSize().width),
                            (scrollArrV[p].getSize().height) / 2 - 1);
                    //Size the new pane and place it
                    scrollArrV[indVWS + 1].setSize((scrollArrV[p].getSize().width),
                            desiredHeight);
                    scrollArrV[indVWS + 1].setLocation(
                            scrollArrV[p].getX(),
                            scrollArrV[p].getY() + scrollArrV[p].getSize().height + 2);
                    indVWS++;
                    hm.put(textArrV[p].getText(), indVWS);
                }
            }
        }
        out.writeObject(hm);
        fileOut.close();
    }
    // End of split workspaces (Robertson)
}
