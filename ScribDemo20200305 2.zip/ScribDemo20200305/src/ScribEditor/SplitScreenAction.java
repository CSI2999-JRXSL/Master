/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;
//IGNORE THIS IT IS WORTHLESS
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import static javax.swing.UIManager.get;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.StyledEditorKit;

/**
 *
 * @author robertsonbrinker
 */
public class SplitScreenAction extends StyledEditorKit.StyledTextAction{
//IGNORE THIS WHOLE CLASS IT IS WORTHLESS
    public SplitScreenAction() {
        super("split");
    }
    
    public JTextPane getTextPane (ActionEvent e)
      {
        //return (JTextPane)e.getSource();
        return (JTextPane) get(e);
      }
    
    public void actionPerformed(ActionEvent e) {
       
        JTextPane textPane = getTextPane(e);
        
             int width = textPane.getSize().width;
             System.out.println(width);
        
       
        //int width = scrollPane.getSize().width;
        //JEditorPane editor = getEditor(e);
        //scrollPane.setSize(10, 10);
        //editor.setSize(10, 10);
        //System.out.println(width);
        
       
        //JEditorPane editor = getEditor(e);
        //JScrollPane ScrollPane1 = getSelectedValue(e);
        //StyledEditorKit kit = getStyledEditorKit(editor);
        //MutableAttributeSet attr = kit.getInputAttributes();
        //String content = editor.getText();
        
        //editor.setVisible(false);
        
//        JScrollPane ScrollPane1 = new javax.swing.JScrollPane();
//        JScrollPane ScrollPane2 = new javax.swing.JScrollPane();
//        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
//                ScrollPane1, ScrollPane2);
//        
//        
//        
//        splitPane.setOneTouchExpandable(true);
//        splitPane.setDividerLocation(150);
//        
//        ScrollPane1.setVisible(true);
//        ScrollPane2.setVisible(true);
//
////Provide minimum sizes for the two components in the split pane
//        Dimension minimumSize = new Dimension(100, 50);
//        ScrollPane1.setMinimumSize(minimumSize);
//        ScrollPane2.setMinimumSize(minimumSize);
    }
    
}
