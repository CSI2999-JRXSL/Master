
package ScribEditor;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.UIManager;


public class ScribDemo {

  
    public static void main(String[] args) throws Exception {
        
//        final JPopupMenu popup = new JPopupMenu();
//        // New project menu item
//        JMenuItem menuItem = new JMenuItem("New Project...",
//                new ImageIcon("images/newproject.png"));
//        menuItem.setMnemonic(KeyEvent.VK_P);
//        menuItem.getAccessibleContext().setAccessibleDescription(
//                "New Project");
//        menuItem.addActionListener(new ActionListener() {
// 
//            public void actionPerformed(ActionEvent e) {
//                JOptionPane.showMessageDialog(frame, "New Project clicked!");
//            }
//        });
//        popup.add(menuItem);
//        // New File menu item
//        menuItem = new JMenuItem("New File...",
//                new ImageIcon("images/newfile.png"));
//        menuItem.setMnemonic(KeyEvent.VK_F);
//        menuItem.addActionListener(new ActionListener() {
// 
//            public void actionPerformed(ActionEvent e) {
//                JOptionPane.showMessageDialog(frame, "New File clicked!");
//            }
//        });
//        popup.add(menuItem);
// 
//        // add mouse listener
//        frame.addMouseListener(new MouseAdapter() {
// 
//            
//            public void mousePressed(MouseEvent e) {
//                showPopup(e);
//            }
// 
//            
//            public void mouseReleased(MouseEvent e) {
//                showPopup(e);
//            }
// 
//            private void showPopup(MouseEvent e) {
//                if (e.isPopupTrigger()) {
//                    popup.show(e.getComponent(),
//                            e.getX(), e.getY());
//                }
//            }
//        });
        
        
        //Start of Julia's feature(s)
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        //End of Julia's feature(s)
        //Start of Scrib call, written by Xi
        ScribPadGui obj = new ScribPadGui();
        obj.setBounds(0, 0, 600, 500);
        obj.setTitle("Scrib");
        obj.setResizable(true);
        obj.setVisible(true);
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //End of Scrib call, written by Xi
    }
    
}
