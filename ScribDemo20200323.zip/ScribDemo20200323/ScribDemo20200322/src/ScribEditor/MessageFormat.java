/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ScribEditor;

/**
 *
 * @author Xi
 */
public class MessageFormat {
        private String temp;
    public MessageFormat(String pattern){
         temp = new MessageFormat(pattern);  
         return temp;
    }
}
