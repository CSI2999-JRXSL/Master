//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
package ScribEditor;
//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledEditorKit;
//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
//IGNORE ME IGNORE ME IGNORE ME IGNORE ME
/**
 *
 * @author robertsonbrinker
 */
//public talk(){
//    
//}
//
//    /**
//     * Toggles the StrikeThrough attribute.
//     *
//     * @param e the action event
//     */
//    public void talk(ActionEvent e) {
//        
//        if (e.getSource() == readTextAloud) {
//            Voice voice;//Creating object of Voice class
//            voice = VoiceManager.getInstance().getVoice("kevin");//Getting voice
//            if (voice != null) {
//                voice.allocate();//Allocating Voice
//            }
//            try {
//                voice.setRate(190);//Setting the rate of the voice
//                voice.setPitch(150);//Setting the Pitch of the voice
//                voice.setVolume(3);//Setting the volume of the voice 
//                voice.speak(getFocusedComponent().getText());//Calling speak() method
// 
// 
//            } catch (Exception e1) {
//                e1.printStackTrace();
//            }
// 
//        }
// 
//    }
//}
